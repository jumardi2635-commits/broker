from PIL import Image, ImageDraw, ImageFont
import os

def create_logo():
    os.makedirs('static/img', exist_ok=True)
    img = Image.new('RGB', (200, 60), color=(17, 24, 39))
    draw = ImageDraw.Draw(img)

    # Try to use arial bold, fallback to default
    try:
        font = ImageFont.truetype("arialbd.ttf", 32)
    except:
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 32)
        except:
            font = ImageFont.load_default()

    # Draw TraderPro text with gradient effect (simulated with two colors)
    draw.text((10, 10), "TRADE", fill=(34, 211, 238), font=font)
    # Measure text to position "Pro"
    trader_width = draw.textlength("ASNB", font=font)
    draw.text((10 + trader_width, 10), "TRADE", fill=(34, 197, 94), font=font)

    img.save('static/img/logo.png')
    print("Logo created at static/img/logo.png")

if __name__ == "__main__":
    create_logo()