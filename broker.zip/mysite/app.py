#!/usr/bin/env python3
# ============================================================
# Global Market — Professional Trading Platform Backend
# Semua saldo & transaksi dalam MYR (Ringgit Malaysia)
# ============================================================
import os
import sys
import signal
import random
import hashlib
import hmac
import time
import json
import logging
import filetype
import warnings
warnings.filterwarnings('ignore', message=r'.*urllib3.*or chardet.*')
from io import BytesIO
from pathlib import Path
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from functools import wraps
from logging.handlers import RotatingFileHandler
from zoneinfo import ZoneInfo

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, jsonify, abort, make_response, send_file
)
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect, CSRFError
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib import colors
from reportlab.lib.units import inch, mm
from google_auth_oauthlib.flow import Flow
from google.oauth2 import id_token
from google.auth.transport import requests as google_requests

# ==== NEW IMPORT untuk PDF broker-grade ====
from pdf_generator import generate_professional_voucher

load_dotenv()

# ------------------------------------------------------------
# Logging Configuration
# ------------------------------------------------------------
class SensitiveDataFilter(logging.Filter):
    def filter(self, record):
        if hasattr(record, 'msg'):
            record.msg = str(record.msg).replace('password', '[REDACTED]')
        return True

formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
file_handler = RotatingFileHandler('globalmarket.log', maxBytes=10_485_760, backupCount=5)
file_handler.setFormatter(formatter)
file_handler.setLevel(logging.INFO)
file_handler.addFilter(SensitiveDataFilter())

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
console_handler.setLevel(logging.INFO)
console_handler.addFilter(SensitiveDataFilter())

logging.basicConfig(level=logging.INFO, handlers=[file_handler, console_handler])
logger = logging.getLogger(__name__)

# ------------------------------------------------------------
# Helper: clean decimal input
# ------------------------------------------------------------
def clean_decimal_input(value):
    if value is None:
        return Decimal('0')
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return Decimal(str(value))
    s = str(value).strip()
    if not s:
        return Decimal('0')
    s = s.replace(',', '').replace(' ', '')
    try:
        return Decimal(s)
    except InvalidOperation:
        import re
        match = re.search(r'[-+]?\d*\.?\d+', s)
        if match:
            return Decimal(match.group())
        return Decimal('0')

def utc_now():
    return datetime.now(timezone.utc)

def get_local_tz():
    tz_str = SYSTEM_SETTINGS.get('timezone', 'UTC')
    try:
        return ZoneInfo(tz_str)
    except Exception:
        try:
            return ZoneInfo('UTC')
        except Exception:
            if 'Kuala_Lumpur' in tz_str or 'Jakarta' in tz_str or 'Singapore' in tz_str:
                return timezone(timedelta(hours=8))
            return timezone.utc

# ------------------------------------------------------------
# App & Extensions
# ------------------------------------------------------------
app = Flask(__name__)

@app.template_filter('hash')
def _hash_filter(value):
    return hashlib.sha256(str(value).encode('utf-8')).hexdigest()[:16]

app.secret_key = os.environ.get("SECRET_KEY")
if not app.secret_key:
    if os.environ.get("FLASK_ENV") == "production":
        raise ValueError("SECRET_KEY must be set in production environment")
    app.secret_key = "dev_secret_key_change_in_production"
    logger.warning("Using default SECRET_KEY – not secure for production!")

limiter = Limiter(get_remote_address, app=app,
                  default_limits=["2000 per day", "300 per hour"],
                  storage_uri=os.environ.get("RATELIMIT_STORAGE_URI", "memory://"))

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL", "sqlite:///globalmarket.db"
).replace("postgres://", "postgresql://")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=1)
SECURE_COOKIE = os.environ.get("SECURE_COOKIE", "False").lower() == "true"
app.config["SESSION_COOKIE_SECURE"] = SECURE_COOKIE
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "None" if SECURE_COOKIE else "Lax"
app.config['SESSION_COOKIE_PARTITIONED'] = SECURE_COOKIE
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024

UPLOAD_FOLDER = os.path.join(app.static_folder, 'uploads')
PROFILE_UPLOAD_FOLDER = os.path.join(UPLOAD_FOLDER, 'profiles')
FORUM_UPLOAD_FOLDER = os.path.join(UPLOAD_FOLDER, 'forum')
KYC_UPLOAD_FOLDER = os.path.join(app.instance_path, 'private_kyc')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
os.makedirs(app.instance_path, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROFILE_UPLOAD_FOLDER, exist_ok=True)
os.makedirs(FORUM_UPLOAD_FOLDER, exist_ok=True)
os.makedirs(KYC_UPLOAD_FOLDER, exist_ok=True)
try:
    os.chmod(KYC_UPLOAD_FOLDER, 0o755)
except OSError:
    pass

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['PROFILE_UPLOAD_FOLDER'] = PROFILE_UPLOAD_FOLDER
app.config['FORUM_UPLOAD_FOLDER'] = FORUM_UPLOAD_FOLDER
app.config['KYC_UPLOAD_FOLDER'] = KYC_UPLOAD_FOLDER

app.config['GOOGLE_CLIENT_ID'] = os.environ.get('GOOGLE_CLIENT_ID', '').strip()
app.config['GOOGLE_CLIENT_SECRET'] = os.environ.get('GOOGLE_CLIENT_SECRET', '').strip()
if not app.config['GOOGLE_CLIENT_ID'] or not app.config['GOOGLE_CLIENT_SECRET']:
    logger.warning("GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET belum diset di environment variable. Login Google akan dinonaktifkan sampai diisi.")

_raw_tg_token = os.environ.get('TELEGRAM_BOT_TOKEN', '').strip()
app.config['TELEGRAM_BOT_TOKEN'] = _raw_tg_token
app.config['TELEGRAM_BOT_NAME'] = os.environ.get('TELEGRAM_BOT_NAME', '').strip().lstrip('@')
app.config['TELEGRAM_BOT_ID'] = (
    os.environ.get('CLIENT_ID') or
    os.environ.get('TELEGRAM_BOT_ID') or
    (_raw_tg_token.split(':')[0] if ':' in _raw_tg_token else '')
)

db = SQLAlchemy(app)
migrate = Migrate(app, db)
csrf = CSRFProtect(app)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# ------------------------------------------------------------
# Jinja2 Filters for Localization
# ------------------------------------------------------------
@app.template_filter('localize')
def _localize_filter(dt):
    if not dt:
        return None
    tz_str = SYSTEM_SETTINGS.get('timezone', 'UTC')
    try:
        tz = ZoneInfo(tz_str)
    except Exception:
        tz = ZoneInfo('UTC')
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(tz)

@app.template_filter('datetimeformat')
def _datetimeformat_filter(dt, fmt='%d %b %Y, %H:%M'):
    if not dt:
        return '—'
    localized = _localize_filter(dt)
    return localized.strftime(fmt) if localized else '—'

# ------------------------------------------------------------
# File & Image Helpers
# ------------------------------------------------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_image(file_storage):
    if not file_storage or not file_storage.filename:
        return False
    if not allowed_file(file_storage.filename):
        return False
    kind = filetype.guess(file_storage.stream)
    if kind is None or kind.mime not in {'image/png', 'image/jpeg'}:
        return False
    file_storage.stream.seek(0)
    return True

def save_kyc_document(user, file_storage):
    if not validate_image(file_storage):
        raise ValueError('Upload IC must be a PNG or JPG image under 2 MB.')
    ext = file_storage.filename.rsplit('.', 1)[1].lower()
    filename = secure_filename(f"ic_{user.id}_{os.urandom(12).hex()}.{ext}")
    path = os.path.join(app.config['KYC_UPLOAD_FOLDER'], filename)
    try:
        file_storage.save(path)
    except PermissionError as e:
        logger.error(f"Permission denied saving KYC file: {e}")
        raise ValueError("Server cannot save the file. Please try again later or contact support.")
    kyc = user.kyc_verification or KycVerification(user_id=user.id)
    kyc.document_path = path
    kyc.status = 'pending'
    kyc.bank_account_status = kyc.bank_account_status or 'not_submitted'
    kyc.rejection_note = ''
    kyc.submitted_at = utc_now()
    kyc.reviewed_at = None
    kyc.reviewer_id = None
    db.session.add(kyc)
    return kyc

# ------------------------------------------------------------
# System Settings
# ------------------------------------------------------------
SETTINGS_FILE = Path(__file__).parent / 'system_settings.json'

def load_system_settings():
    defaults = {
        'site_name': 'Global Market',
        'site_tagline': 'Professional Trading Platform',
        'default_currency': 'MYR',
        'timezone': 'UTC',
        'date_format': 'Y-m-d',
        'time_format': 'H:i',
        'items_per_page': 25,
        'email_notifications': True,
        'browser_notifications': False,
        'sound_alerts': False,
        'maintenance_mode': False,
        'admin_name': 'Administrator',
        'admin_email': 'admin@globalmarket.com',
        'session_timeout': 60,
        'two_factor_enabled': False,
        'referral_level1_rate': 10.0,
        'referral_level2_rate': 3.0,
        'referral_level3_rate': 1.0,
        'welcome_bonus_amount': 50.0,
        'forum_auto_approve': False,
        'kyc_status_messages': {
            'required': 'Please upload your document below. Verification is required prior to processing fund withdrawals.',
            'pending': 'Your document is under compliance review. Standard review time is under 12 hours.',
            'approved': 'Account verification is approved. Withdrawal access is enabled after bank account verification is also approved.',
            'rejected': 'Your document could not be approved. Please upload a clearer or valid document.'
        }
    }
    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                saved = json.load(f)
                defaults.update(saved)
                saved_kyc_messages = saved.get('kyc_status_messages', {})
                if isinstance(saved_kyc_messages, dict):
                    defaults['kyc_status_messages'].update(saved_kyc_messages)
        except Exception as e:
            logger.error(f"Failed to load settings file: {e}", exc_info=True)
    return defaults

def save_system_settings(settings):
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Failed to save settings file: {e}", exc_info=True)

SYSTEM_SETTINGS = load_system_settings()

# ------------------------------------------------------------
# Models
# ------------------------------------------------------------
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256))
    saldo = db.Column(db.Numeric(10, 2), default=Decimal('0.00'))
    bank_name = db.Column(db.String(100), default="")
    bank_account = db.Column(db.String(100), default="")
    bank_account_name = db.Column(db.String(100), default="")
    profile_picture = db.Column(db.String(256), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    role = db.Column(db.String(20), default="user")
    preferred_currency = db.Column(db.String(3), default="MYR")
    custom_winrate = db.Column(db.Integer, default=50, nullable=True)
    google_id = db.Column(db.String(120), unique=True, nullable=True)
    telegram_id = db.Column(db.String(64), unique=True, nullable=True)
    referral_code = db.Column(db.String(16), unique=True, nullable=True, index=True)
    referred_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True, index=True)

    referrer = db.relationship('User', remote_side=[id], foreign_keys=[referred_by_id], backref=db.backref('direct_referrals', lazy='dynamic'))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return bool(self.password_hash) and check_password_hash(self.password_hash, password)

    @property
    def balance_float(self):
        return float(self.saldo)

    def ensure_referral_code(self):
        if not self.referral_code:
            import string
            while True:
                candidate = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
                if not User.query.filter_by(referral_code=candidate).first():
                    self.referral_code = candidate
                    break
        return self.referral_code

    def get_downlines_by_level(self):
        l1 = list(self.direct_referrals.all())
        l1_ids = [u.id for u in l1]
        l2 = User.query.filter(User.referred_by_id.in_(l1_ids)).all() if l1_ids else []
        l2_ids = [u.id for u in l2]
        l3 = User.query.filter(User.referred_by_id.in_(l2_ids)).all() if l2_ids else []
        return {'level1': l1, 'level2': l2, 'level3': l3}

    @property
    def total_referral_count(self):
        downlines = self.get_downlines_by_level()
        return len(downlines['level1']) + len(downlines['level2']) + len(downlines['level3'])

    @property
    def total_commission_earned(self):
        total = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(referrer_id=self.id, status='paid').scalar()
        return total or Decimal('0.00')

    def __repr__(self):
        return f"<User {self.email}>"

class Transaction(db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    type = db.Column(db.String(20), nullable=False, default='topup')
    amount = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0.00'))
    description = db.Column(db.String(200), default="")
    status = db.Column(db.String(20), default='pending')
    admin_notes = db.Column(db.String(200), default="")
    created_at = db.Column(db.DateTime, default=utc_now)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now)
    bank_name = db.Column(db.String(100), default="")
    bank_account = db.Column(db.String(100), default="")
    bank_account_name = db.Column(db.String(100), default="")
    user = db.relationship('User', backref=db.backref('transactions', lazy='dynamic'))

    @property
    def amount_float(self):
        return float(self.amount)

class TradeHistory(db.Model):
    __tablename__ = 'trade_history'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    source = db.Column(db.String(20), nullable=False, default='admin')
    symbol = db.Column(db.String(32), nullable=False, default='UNKNOWN')
    direction = db.Column(db.String(8), nullable=False, default='buy')
    opened_at = db.Column(db.DateTime, nullable=True)
    closed_at = db.Column(db.DateTime, nullable=False, default=utc_now, index=True)
    volume = db.Column(db.Numeric(14, 4), nullable=False, default=Decimal('0'))
    entry_price = db.Column(db.Numeric(18, 8), nullable=True)
    exit_price = db.Column(db.Numeric(18, 8), nullable=True)
    pnl = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('0.00'))
    commission = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('0.00'))
    swap = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('0.00'))
    fee = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('0.00'))
    notes = db.Column(db.String(500), nullable=False, default='')
    created_at = db.Column(db.DateTime, nullable=False, default=utc_now)
    updated_at = db.Column(db.DateTime, nullable=False, default=utc_now, onupdate=utc_now)
    user = db.relationship('User', backref=db.backref('trade_history', lazy='dynamic'))

class TradeAuditLog(db.Model):
    __tablename__ = 'trade_audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    trade_id = db.Column(db.Integer, nullable=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    action = db.Column(db.String(20), nullable=False)
    before_data = db.Column(db.Text, nullable=False, default='{}')
    after_data = db.Column(db.Text, nullable=False, default='{}')
    created_at = db.Column(db.DateTime, nullable=False, default=utc_now)

class KycVerification(db.Model):
    __tablename__ = 'kyc_verifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, unique=True, index=True)
    document_path = db.Column(db.String(512), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='not_submitted', index=True)
    bank_account_status = db.Column(db.String(20), nullable=False, default='not_submitted', index=True)
    rejection_note = db.Column(db.String(500), nullable=False, default='')
    submitted_at = db.Column(db.DateTime, nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    user = db.relationship('User', foreign_keys=[user_id], backref=db.backref('kyc_verification', uselist=False))

class BonusCampaign(db.Model):
    __tablename__ = 'bonus_campaigns'
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(500), default="")
    amount = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0.00'))
    bonus_type = db.Column(db.String(30), default="milestone")
    target = db.Column(db.Integer, default=1)
    min_deposit = db.Column(db.Numeric(10, 2), default=Decimal('0.00'))
    badge = db.Column(db.String(30), default="Hot")
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=utc_now)

class UserBonus(db.Model):
    __tablename__ = 'user_bonuses'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('bonus_campaigns.id'), nullable=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(500), default="")
    amount = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0.00'))
    status = db.Column(db.String(20), default="locked")
    progress = db.Column(db.Integer, default=0)
    target = db.Column(db.Integer, default=1)
    claimed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)

    user = db.relationship('User', backref=db.backref('user_bonuses', lazy='dynamic', cascade='all, delete-orphan'))
    campaign = db.relationship('BonusCampaign', backref=db.backref('user_grants', lazy='dynamic'))

class ReferralCommission(db.Model):
    __tablename__ = 'referral_commissions'
    id = db.Column(db.Integer, primary_key=True)
    referrer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    downline_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    level = db.Column(db.Integer, nullable=False, default=1)
    rate = db.Column(db.Numeric(5, 2), default=Decimal('10.00'))
    source_amount = db.Column(db.Numeric(10, 2), default=Decimal('0.00'))
    amount = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0.00'))
    status = db.Column(db.String(20), default="paid")
    source_tx_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)

    referrer = db.relationship('User', foreign_keys=[referrer_id], backref=db.backref('commissions_earned', lazy='dynamic'))
    downline = db.relationship('User', foreign_keys=[downline_id])
    source_transaction = db.relationship('Transaction')

class ForumPost(db.Model):
    __tablename__ = 'forum_posts'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, default="")
    amount = db.Column(db.Numeric(10, 2), nullable=False, default=Decimal('0.00'))
    bank_name = db.Column(db.String(100), default="")
    image_url = db.Column(db.String(256), nullable=True)
    status = db.Column(db.String(20), default="approved")
    is_pinned = db.Column(db.Boolean, default=False)
    likes_count = db.Column(db.Integer, default=0)
    views_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=utc_now)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now)

    user = db.relationship('User', backref=db.backref('forum_posts', lazy='dynamic'))
    comments = db.relationship('ForumComment', backref='post', lazy='dynamic', cascade='all, delete-orphan')
    likes = db.relationship('ForumLike', backref='post', lazy='dynamic', cascade='all, delete-orphan')

class ForumComment(db.Model):
    __tablename__ = 'forum_comments'
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('forum_posts.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="active")
    created_at = db.Column(db.DateTime, default=utc_now)

    user = db.relationship('User')

class ForumLike(db.Model):
    __tablename__ = 'forum_likes'
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('forum_posts.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utc_now)

    __table_args__ = (db.UniqueConstraint('post_id', 'user_id', name='_user_post_like_uc'),)

# ------------------------------------------------------------
# Currency Helpers (hanya MYR)
# ------------------------------------------------------------
SUPPORTED_CURRENCIES = ['MYR']
CURRENCY_SYMBOLS = {'MYR': 'RM'}

def format_currency(amount, currency='MYR', include_symbol=True):
    if not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    formatted = f"{amount:,.2f}"
    if include_symbol:
        return f"RM{formatted}"
    return formatted

def get_user_currency():
    return 'MYR'

def user_balance_display(user):
    return format_currency(user.saldo, 'MYR')

def convert_currency_dummy(amount, from_currency, to_currency):
    if not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    return amount

def get_exchange_rate_dummy(from_currency, to_currency='USD'):
    return Decimal('1.0')

BANK_OPTIONS = [
    ('maybank', 'Maybank'), ('cimb', 'CIMB'), ('public-bank', 'Public Bank'),
    ('rhb', 'RHB'), ('hong-leong', 'Hong Leong'), ('ambank', 'AmBank'),
    ('bank-islam', 'Bank Islam'), ('bank-rakyat', 'Bank Rakyat'),
    ('bsn', 'Bank Simpanan Nasional'), ('affin', 'Affin Bank'),
    ('alliance', 'Alliance Bank'), ('agro', 'Agro Bank'),
    ('bank-muamalat', 'Bank Muamalat'), ('aeon', 'Aeon Bank'),
    ('gx', 'GX Bank'), ('bigpay', 'BigPay'), ('tng', "Touch 'n Go eWallet"),
    ('asnb', 'ASNB'), ('other', 'Other Bank'),
]
TRADE_SYMBOLS = ['BTC/USD', 'ETH/USD', 'XAU/USD', 'EUR/USD', 'GBP/USD', 'USD/JPY']
MAX_LEVERAGE = 10

# ------------------------------------------------------------
# Database Seeding
# ------------------------------------------------------------
def check_db_schema_updates():
    try:
        from sqlalchemy import text
        with db.engine.connect() as conn:
            result = conn.execute(text("PRAGMA table_info(user)")).fetchall()
            cols = [r[1] for r in result]
            if 'custom_winrate' not in cols:
                conn.execute(text("ALTER TABLE user ADD COLUMN custom_winrate INTEGER DEFAULT 50"))
                conn.commit()
                logger.info("Added custom_winrate column to user table.")
            if 'google_id' not in cols:
                conn.execute(text("ALTER TABLE user ADD COLUMN google_id VARCHAR(120) UNIQUE"))
                conn.commit()
                logger.info("Added google_id column to user table.")
            if 'telegram_id' not in cols:
                conn.execute(text("ALTER TABLE user ADD COLUMN telegram_id VARCHAR(64) UNIQUE"))
                conn.commit()
                logger.info("Added telegram_id column to user table.")
            if 'referral_code' not in cols:
                conn.execute(text("ALTER TABLE user ADD COLUMN referral_code VARCHAR(16)"))
                conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_user_referral_code ON user(referral_code)"))
                conn.commit()
                logger.info("Added referral_code column to user table.")
            if 'referred_by_id' not in cols:
                conn.execute(text("ALTER TABLE user ADD COLUMN referred_by_id INTEGER REFERENCES user(id)"))
                conn.commit()
                logger.info("Added referred_by_id column to user table.")
    except Exception as e:
        logger.warning(f"Schema update check notice: {e}")

    try:
        users = User.query.filter((User.referral_code == None) | (User.referral_code == '')).all()
        for u in users:
            u.ensure_referral_code()
        if users:
            db.session.commit()
            logger.info(f"Generated referral codes for {len(users)} users.")
    except Exception as e:
        db.session.rollback()
        logger.warning(f"Could not update referral codes for existing users: {e}")

def seed_bonus_campaigns():
    defaults = [
        {'code': 'welcome_bonus', 'title': 'Bonus Selamat Datang',
         'description': 'Kredit trading instan tanpa deposit awal untuk mengawali perjalanan trading Anda.',
         'amount': Decimal('50.00'), 'bonus_type': 'welcome', 'target': 1,
         'min_deposit': Decimal('0.00'), 'badge': 'Hot'},
        {'code': 'first_deposit_bonus', 'title': 'Bonus Deposit Perdana',
         'description': 'Tambahan modal bonus saldo langsung setelah melakukan deposit pertama kali.',
         'amount': Decimal('100.00'), 'bonus_type': 'deposit', 'target': 1,
         'min_deposit': Decimal('100.00'), 'badge': 'Terpopuler'},
        {'code': 'referral_milestone_3', 'title': 'Hadiah Referral 3 Trader',
         'description': 'Ajak 3 rekan bergabung dan trading, dapatkan reward bonus tunai.',
         'amount': Decimal('150.00'), 'bonus_type': 'referral_milestone', 'target': 3,
         'min_deposit': Decimal('0.00'), 'badge': 'Spesial'},
        {'code': 'vip_referral_10', 'title': 'Milestone Afiliasi VIP 10 Rekan',
         'description': 'Bangun jaringan afiliasi 10 member aktif dan nikmati bonus saldo eksklusif.',
         'amount': Decimal('500.00'), 'bonus_type': 'referral_milestone', 'target': 10,
         'min_deposit': Decimal('0.00'), 'badge': 'VIP'}
    ]
    for d in defaults:
        if not BonusCampaign.query.filter_by(code=d['code']).first():
            camp = BonusCampaign(**d)
            db.session.add(camp)
    try:
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.warning(f"Failed to seed bonus campaigns: {e}")

def seed_forum_posts():
    if ForumPost.query.count() == 0:
        demo = User.query.filter_by(role='user').first()
        admin = User.query.filter_by(role='admin').first()
        author = demo or admin
        if author:
            samples = [
                {'user_id': author.id, 'title': 'Penarikan Mingguan Sukses Masuk ke Rekening Maybank',
                 'content': 'Alhamdulillah penarikan hasil profit scalping minggu ini sebesar RM 1,850 langsung cair kurang dari 15 menit. Broker sangat transparan dan eksekusinya cepat tanpa requote. Terima kasih tim Global Market!',
                 'amount': Decimal('1850.00'), 'bank_name': 'Maybank', 'image_url': '',
                 'status': 'approved', 'is_pinned': True, 'likes_count': 24, 'views_count': 342,
                 'created_at': utc_now() - timedelta(hours=5)},
                {'user_id': author.id, 'title': 'Pencairan Profit XAU/USD Pertama Saya Lancar!',
                 'content': 'Awalnya sempat ragu, tapi ternyata proses penarikan dana sangat mudah dan cepat. Dana RM 3,200 mendarat aman di CIMB.',
                 'amount': Decimal('3200.00'), 'bank_name': 'CIMB Bank', 'image_url': '',
                 'status': 'approved', 'is_pinned': False, 'likes_count': 18, 'views_count': 210,
                 'created_at': utc_now() - timedelta(days=1, hours=3)},
                {'user_id': author.id, 'title': 'Withdrawal RM 950 ke Touch \'n Go Berhasil',
                 'content': 'Uji coba penarikan via e-wallet TNG langsung sukses dalam sekejap.',
                 'amount': Decimal('950.00'), 'bank_name': 'Touch \'n Go eWallet', 'image_url': '',
                 'status': 'approved', 'is_pinned': False, 'likes_count': 12, 'views_count': 180,
                 'created_at': utc_now() - timedelta(days=2, hours=8)}
            ]
            for s in samples:
                db.session.add(ForumPost(**s))
            try:
                db.session.commit()
            except SQLAlchemyError as e:
                db.session.rollback()
                logger.warning(f"Failed to seed forum posts: {e}")

def seed_database():
    if not User.query.filter_by(email='admin@globalmarket.com').first():
        admin = User(username="admin", email="admin@globalmarket.com", saldo=Decimal('0.00'),
                     is_active=True, role="admin", preferred_currency="MYR")
        admin.set_password("admin123")
        admin.ensure_referral_code()
        db.session.add(admin)
        logger.info("Admin user created.")

    if not User.query.filter_by(email='demo@globalmarket.com').first():
        demo = User(username="demo_trader", email="demo@globalmarket.com", saldo=Decimal('1000.00'),
                    bank_name="Maybank", bank_account="1234567890",
                    bank_account_name="Demo Account", preferred_currency="MYR", role="user")
        demo.set_password("demo123")
        demo.ensure_referral_code()
        db.session.add(demo)
        db.session.flush()
        if demo.id:
            tx = Transaction(user_id=demo.id, type='topup', amount=Decimal('1000.00'),
                             description='Initial demo balance', status='approved')
            db.session.add(tx)
        logger.info("Demo user created.")
    try:
        db.session.commit()
        logger.info("Seed data ensured.")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to seed database: {e}", exc_info=True)

    seed_bonus_campaigns()
    seed_forum_posts()

def migrate_legacy_trades():
    pass

with app.app_context():
    check_db_schema_updates()
    db.create_all()
    seed_database()
    migrate_legacy_trades()

# ------------------------------------------------------------
# Context Processors
# ------------------------------------------------------------
@app.context_processor
def inject_globals():
    display_currency = 'MYR'
    current_user = None
    user_balance_display_str = format_currency(Decimal('0.00'), 'MYR')
    user_id = session.get('user_id')
    if user_id:
        current_user = db.session.get(User, user_id)
        if current_user is not None:
            user_balance_display_str = format_currency(current_user.saldo, 'MYR')

    pending_total = 0
    total_users_count = 0
    active_users_count = 0
    pending_forum_count = 0
    active_campaigns_count = 0
    if session.get('admin'):
        pending_total = Transaction.query.filter_by(status='pending').count()
        total_users_count = User.query.count()
        active_users_count = User.query.filter_by(is_active=True).count()
        pending_forum_count = ForumPost.query.filter_by(status='pending').count()
        active_campaigns_count = BonusCampaign.query.filter_by(is_active=True).count()

    local_tz = get_local_tz()
    local_now = datetime.now(local_tz)

    def to_local(dt):
        if not dt:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(local_tz)

    def fmt_local(dt, pattern='%d %b %Y, %H:%M'):
        loc = to_local(dt)
        return loc.strftime(pattern) if loc else '—'

    tg_name = (SYSTEM_SETTINGS.get('telegram_bot_name') or app.config.get('TELEGRAM_BOT_NAME', '')).strip().lstrip('@')
    tg_token = (SYSTEM_SETTINGS.get('telegram_bot_token') or app.config.get('TELEGRAM_BOT_TOKEN', '')).strip()
    tg_id = app.config.get('TELEGRAM_BOT_ID', '')
    if not tg_id and ':' in tg_token:
        tg_id = tg_token.split(':')[0]

    return {
        'datetime': datetime, 'len': len, 'now': utc_now(),
        'local_now': local_now, 'local_tz': local_tz,
        'to_local': to_local, 'fmt_local': fmt_local,
        'telegram_bot_name': tg_name, 'telegram_bot_id': tg_id,
        'supported_currencies': SUPPORTED_CURRENCIES,
        'currency_symbols': CURRENCY_SYMBOLS,
        'get_user_currency': get_user_currency,
        'format_currency': format_currency,
        'user_balance_display': user_balance_display,
        'system_settings': SYSTEM_SETTINGS,
        'default_currency': 'MYR', 'display_currency': 'MYR',
        'current_user': current_user,
        'user_balance_display_str': user_balance_display_str,
        'pending_total': pending_total,
        'total_users': total_users_count,
        'active_users': active_users_count,
        'pending_forum_count': pending_forum_count,
        'active_campaigns_count': active_campaigns_count,
        'logo': SYSTEM_SETTINGS.get('site_logo'),
        'convert_currency': convert_currency_dummy,
        'get_exchange_rate': get_exchange_rate_dummy,
    }

# ------------------------------------------------------------
# Security Helpers
# ------------------------------------------------------------
def regenerate_session():
    session.modified = True
    temp = dict(session)
    session.clear()
    session.update(temp)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin'):
            flash("Admin access required.", "danger")
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# ------------------------------------------------------------
# Error Handlers
# ------------------------------------------------------------
@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    logger.warning(f"CSRF validation failed: {request.remote_addr}")
    flash("The form you submitted is invalid. Please try again.", "danger")
    return redirect(request.referrer or url_for('index'))

@app.errorhandler(400)
def bad_request(e): return render_template('error.html', error="Bad request", error_code=400), 400
@app.errorhandler(401)
def unauthorized(e): return render_template('error.html', error="Authentication required", error_code=401), 401
@app.errorhandler(403)
def forbidden(e): return render_template('error.html', error="You do not have permission to access this page", error_code=403), 403
@app.errorhandler(404)
def not_found(e): return render_template('error.html', error="Page not found", error_code=404), 404
@app.errorhandler(405)
def method_not_allowed(e): return render_template('error.html', error="Method not allowed", error_code=405), 405
@app.errorhandler(413)
def request_too_large(e): return render_template('error.html', error="Uploaded file is too large (max 2 MB)", error_code=413), 413
@app.errorhandler(429)
def too_many_requests(e): return render_template('error.html', error="Too many requests. Please slow down and try again later.", error_code=429), 429
@app.errorhandler(500)
def internal_error(e):
    db.session.rollback()
    logger.error(f"500 error at {request.url}: {e}", exc_info=True)
    return render_template('error.html', error="Internal server error", error_code=500), 500
@app.errorhandler(SQLAlchemyError)
def handle_db_error(e):
    db.session.rollback()
    logger.error(f"Database error: {e}", exc_info=True)
    flash("A database error occurred. Please try again later.", "danger")
    return redirect(request.referrer or url_for('index'))
@app.errorhandler(IntegrityError)
def handle_integrity_error(e):
    db.session.rollback()
    logger.error(f"Integrity error: {e}", exc_info=True)
    flash("Data conflict. The operation could not be completed.", "danger")
    return redirect(request.referrer or url_for('index'))

# ------------------------------------------------------------
# Middleware
# ------------------------------------------------------------
@app.before_request
def check_user_active():
    ref = request.args.get('ref')
    if ref and ref.strip():
        session['referral_code'] = ref.strip()

    user_id = session.get('user_id')
    if user_id:
        user = db.session.get(User, user_id)
        if user and not user.is_active:
            session.clear()
            flash("Akaun anda telah dinyahaktifkan.", "danger")
            return redirect(url_for('login'))

# ------------------------------------------------------------
# User Routes
# ------------------------------------------------------------
@app.route('/')
def index():
    user_id = session.get("user_id")
    if not user_id:
        return render_template("landing.html")
    user = db.session.get(User, user_id)
    if not user or not user.is_active:
        session.clear()
        return redirect(url_for("login"))

    recent_txs = Transaction.query.filter(Transaction.user_id == user_id, Transaction.type.in_(['topup', 'withdraw']))\
        .order_by(Transaction.created_at.desc()).limit(5).all()
    approved_txs = Transaction.query.filter_by(user_id=user_id, status='approved').all()
    metrics = trade_metrics(user_id)
    today = datetime.now(get_local_tz()).date()
    period_pnl = {}
    for key, start in [('daily', today), ('weekly', today - timedelta(days=6)), ('monthly', today.replace(day=1))]:
        period_pnl[key] = db.session.query(db.func.sum(TradeHistory.pnl)).filter(
            TradeHistory.user_id == user_id,
            db.func.date(TradeHistory.closed_at) >= start,
            TradeHistory.closed_at <= utc_now()
        ).scalar() or Decimal('0.00')
    total_profit = sum((t.amount for t in approved_txs if t.type == 'topup'), Decimal('0.00'))
    total_loss = sum((t.amount for t in approved_txs if t.type == 'withdraw'), Decimal('0.00'))
    active_trades = 0
    chart_labels, chart_data = [], []
    for i in range(6, -1, -1):
        day = datetime.now(get_local_tz()).date() - timedelta(days=i)
        chart_labels.append(day.strftime('%a'))
        day_net = db.session.query(db.func.sum(TradeHistory.pnl)).filter(
            TradeHistory.user_id == user_id,
            db.func.date(TradeHistory.closed_at) == day
        ).scalar() or Decimal('0.00')
        chart_data.append(float(day_net))
    best_trade = db.session.query(db.func.max(TradeHistory.pnl)).filter_by(user_id=user_id).scalar() or Decimal('0.00')

    return render_template("index.html", user=user, transactions=recent_txs,
                           total_profit=total_profit, total_loss=total_loss,
                           active_trades=active_trades, chart_labels=chart_labels,
                           chart_data=chart_data, trade_metrics=metrics,
                           period_pnl=period_pnl, best_trade=best_trade)

# ------------------------------------------------------------
# Google OAuth
# ------------------------------------------------------------
def _google_flow(state=None):
    client_id = app.config.get('GOOGLE_CLIENT_ID', '')
    client_secret = app.config.get('GOOGLE_CLIENT_SECRET', '')
    if not client_id or not client_secret:
        logger.warning("Google OAuth belum dikonfigurasi: GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET kosong.")
        return None
    config = {'web': {
        'client_id': client_id, 'client_secret': client_secret,
        'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
        'token_uri': 'https://oauth2.googleapis.com/token',
        'redirect_uris': [url_for('google_callback', _external=True)],
    }}
    scopes = ['openid', 'https://www.googleapis.com/auth/userinfo.email',
              'https://www.googleapis.com/auth/userinfo.profile']
    flow = Flow.from_client_config(config, scopes=scopes, state=state)
    flow.redirect_uri = url_for('google_callback', _external=True)
    return flow

def _unique_google_username(email, name):
    base = ''.join(ch for ch in (name or email.split('@')[0]).lower() if ch.isalnum() or ch == '_')[:60] or 'trader'
    candidate, suffix = base, 1
    while User.query.filter_by(username=candidate).first():
        suffix += 1
        candidate = f'{base[:72]}{suffix}'
    return candidate

@app.route('/auth/google')
@limiter.limit('10 per minute')
def google_login():
    flow = _google_flow()
    if not flow:
        flash('Google sign-in is not configured yet. Please use email and password.', 'warning')
        return redirect(url_for('login'))
    authorization_url, state = flow.authorization_url(access_type='offline', include_granted_scopes='true', prompt='select_account')
    session['google_oauth_state'] = state
    return redirect(authorization_url)

@app.route('/auth/google/callback')
@limiter.limit('10 per minute')
def google_callback():
    logger.info(f"Google callback called with URL: {request.url}")
    if request.args.get('error'):
        flash('Google sign-in was cancelled.', 'info')
        return redirect(url_for('login'))
    state = session.pop('google_oauth_state', None)
    if not state or state != request.args.get('state'):
        logger.warning("State mismatch in Google callback")
        abort(400)
    flow = _google_flow(state=state)
    if not flow:
        flash('Google sign-in is not configured.', 'danger')
        return redirect(url_for('login'))
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", Warning)
            flow.fetch_token(authorization_response=request.url)
        if not flow.credentials:
            logger.error("No credentials after fetch_token")
            flash('Google sign-in could not be verified: missing credentials.', 'danger')
            return redirect(url_for('login'))
        id_token_str = flow.credentials.id_token
        if not id_token_str:
            logger.error("No id_token in credentials")
            flash('Google sign-in could not be verified: missing ID token.', 'danger')
            return redirect(url_for('login'))
        id_info = id_token.verify_oauth2_token(id_token_str, google_requests.Request(), app.config['GOOGLE_CLIENT_ID'])
        logger.info(f"ID token verified for email: {id_info.get('email')}")
    except Warning as w:
        logger.warning(f"Scope warning ignored: {w}")
        try:
            id_token_str = flow.credentials.id_token
            if not id_token_str:
                raise ValueError("No id_token")
            id_info = id_token.verify_oauth2_token(id_token_str, google_requests.Request(), app.config['GOOGLE_CLIENT_ID'])
        except Exception as inner_e:
            logger.error(f"Failed to verify token after warning: {inner_e}")
            flash('Google sign-in could not be verified. Please try again.', 'danger')
            return redirect(url_for('login'))
    except ValueError as e:
        logger.error(f"Google token verification failed (ValueError): {e}", exc_info=True)
        flash('Google sign-in could not be verified. Please try again.', 'danger')
        return redirect(url_for('login'))
    except Exception as e:
        logger.error(f"Unexpected error in Google callback: {e}", exc_info=True)
        flash('Pengesahan Google tidak dapat disahkan. Sila cuba lagi.', 'danger')
        return redirect(url_for('login'))

    if id_info.get('iss') not in ('accounts.google.com', 'https://accounts.google.com'):
        logger.warning("Invalid issuer in Google token")
        flash('Pengeluar token Google tidak sah.', 'danger')
        return redirect(url_for('login'))
    if not id_info.get('email_verified'):
        flash('E-mel Google anda mestilah disahkan.', 'danger')
        return redirect(url_for('login'))

    email = str(id_info.get('email', '')).lower().strip()
    if not email:
        flash('Google tidak membekalkan alamat e-mel.', 'danger')
        return redirect(url_for('login'))

    user = User.query.filter_by(email=email).first()
    google_id = id_info.get('sub')
    if not user:
        user = User.query.filter_by(google_id=google_id).first()

    is_new_user = False
    if not user:
        is_new_user = True
        name = id_info.get('name', '')
        username = _unique_google_username(email, name)
        user = User(username=username, email=email, google_id=google_id,
                    saldo=Decimal('0.00'), preferred_currency="MYR", is_active=True)
        submitted_ref = session.get('referral_code')
        if submitted_ref:
            referrer = User.query.filter_by(referral_code=submitted_ref).first()
            if referrer and referrer.id != user.id:
                user.referred_by_id = referrer.id
                logger.info(f"User {email} referred by {referrer.email} (via Google)")
        db.session.add(user)
        logger.info(f"New user created via Google: {email}")
    else:
        if not user.google_id:
            user.google_id = google_id
            logger.info(f"Linked Google ID to existing user: {email}")

    if not user.is_active:
        flash('Akaun anda telah dinyahaktifkan.', 'danger')
        return redirect(url_for('login'))

    user.last_login = utc_now()
    user.ensure_referral_code()
    try:
        if is_new_user:
            db.session.flush()
            init_user_bonuses(user)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"DB error during Google login: {e}", exc_info=True)
        flash('Tidak dapat log masuk. Sila cuba lagi.', 'danger')
        return redirect(url_for('login'))

    regenerate_session()
    session['user_id'] = user.id
    session['username'] = user.username
    session['user_role'] = user.role
    flash(f'Selamat datang, {user.username}!', 'success')
    return redirect(url_for('index'))

# ------------------------------------------------------------
# Telegram OAuth
# ------------------------------------------------------------
def _verify_telegram_auth(data: dict) -> bool:
    bot_token = SYSTEM_SETTINGS.get('telegram_bot_token') or app.config.get('TELEGRAM_BOT_TOKEN', '')
    if not bot_token:
        return False
    check_hash = data.pop('hash', '')
    data_check_arr = ['{}={}'.format(k, v) for k, v in sorted(data.items())]
    data_check_string = '\n'.join(data_check_arr)
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    computed = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, check_hash)

def _unique_telegram_username(first_name, last_name, tg_username):
    base = tg_username or f"{first_name or 'user'}{last_name or ''}"
    base = ''.join(ch for ch in base.lower() if ch.isalnum() or ch == '_')[:60] or 'trader'
    candidate, suffix = base, 1
    while User.query.filter_by(username=candidate).first():
        suffix += 1
        candidate = f'{base[:72]}{suffix}'
    return candidate

@app.route('/auth/telegram/callback')
@limiter.limit('10 per minute')
def telegram_callback():
    bot_token = SYSTEM_SETTINGS.get('telegram_bot_token') or app.config.get('TELEGRAM_BOT_TOKEN', '')
    if not bot_token:
        flash('Log masuk Telegram belum dikonfigurasi. Sila gunakan e-mel dan kata laluan.', 'warning')
        return redirect(url_for('login'))

    tg_data = {k: v for k, v in request.args.items()}
    if not tg_data.get('hash') or not tg_data.get('id'):
        flash('Data Telegram tidak sah atau tidak lengkap.', 'danger')
        return redirect(url_for('login'))

    auth_date = int(tg_data.get('auth_date', 0))
    if time.time() - auth_date > 3600:
        flash('Sesi Telegram telah tamat. Sila cuba semula.', 'danger')
        return redirect(url_for('login'))

    tg_data_copy = dict(tg_data)
    if not _verify_telegram_auth(tg_data_copy):
        logger.warning(f"Telegram auth hash mismatch from IP: {request.remote_addr}")
        flash('Pengesahan Telegram gagal. Sila cuba semula.', 'danger')
        return redirect(url_for('login'))

    tg_id    = str(tg_data.get('id', ''))
    tg_uname = tg_data.get('username', '')
    first    = tg_data.get('first_name', '')
    last     = tg_data.get('last_name', '')
    photo    = tg_data.get('photo_url', '')

    user = User.query.filter_by(telegram_id=tg_id).first()
    if not user and tg_uname:
        user = User.query.filter_by(username=tg_uname).first()

    is_new_user = False
    if not user:
        is_new_user = True
        username = _unique_telegram_username(first, last, tg_uname)
        fake_email = f"tg_{tg_id}@telegram.placeholder"
        user = User(username=username, email=fake_email, telegram_id=tg_id,
                    saldo=Decimal('0.00'), preferred_currency='MYR', is_active=True)
        submitted_ref = session.get('referral_code')
        if submitted_ref:
            referrer = User.query.filter_by(referral_code=submitted_ref).first()
            if referrer and referrer.id != user.id:
                user.referred_by_id = referrer.id
                logger.info(f"User {username} referred by {referrer.email} (via Telegram)")
        db.session.add(user)
        logger.info(f"New user created via Telegram: tg_id={tg_id} username={username}")
    else:
        if not user.telegram_id:
            user.telegram_id = tg_id
            logger.info(f"Linked Telegram ID to existing user: {user.username}")

    if not user.is_active:
        flash('Akaun anda telah dinyahaktifkan.', 'danger')
        return redirect(url_for('login'))

    if photo and not user.profile_picture:
        user.profile_picture = photo

    user.last_login = utc_now()
    user.ensure_referral_code()
    try:
        if is_new_user:
            db.session.flush()
            init_user_bonuses(user)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"DB error during Telegram login: {e}", exc_info=True)
        flash('Ralat berlaku semasa log masuk. Sila cuba semula.', 'danger')
        return redirect(url_for('login'))

    regenerate_session()
    session['user_id']   = user.id
    session['username']  = user.username
    session['user_role'] = user.role
    flash(f'Selamat datang, {user.username}!', 'success')
    return redirect(url_for('index'))

@app.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def login():
    if session.get('user_id'):
        return redirect(url_for('index'))
    if request.method == "POST":
        slider_verified = request.form.get("slider_verified", "")
        if slider_verified != "1":
            flash("Sila selesaikan verifikasi keselamatan (geser ke kanan) terlebih dahulu.", "danger")
            return render_template("login.html")

        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not email or not password:
            flash("E-mel dan kata laluan diperlukan.", "danger")
            return render_template("login.html")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            logger.warning(f"Failed login attempt for email: {email} from IP: {request.remote_addr}")
            flash("E-mel atau kata laluan tidak sah.", "danger")
            return render_template("login.html")
        if not user.is_active:
            flash("Akaun anda telah dinyahaktifkan.", "danger")
            return render_template("login.html")
        regenerate_session()
        session["user_id"] = user.id
        session["username"] = user.username
        session["user_role"] = user.role
        user.last_login = utc_now()
        try:
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error during login: {e}", exc_info=True)
            flash("Ralat berlaku. Sila cuba lagi.", "danger")
            return render_template("login.html")
        logger.info(f"User {user.email} logged in.")
        flash(f"Selamat kembali, {user.username}!", "success")
        return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def register():
    ref_code = request.args.get("ref", "").strip() or session.get("referral_code", "")
    if request.method == "POST":
        slider_verified = request.form.get("slider_verified", "")
        submitted_ref = request.form.get("referral_code", "").strip() or ref_code

        if slider_verified != "1":
            flash("Sila selesaikan verifikasi keselamatan (geser ke kanan) terlebih dahulu.", "danger")
            return render_template("register.html", ref_code=submitted_ref)

        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        errors = []
        if not username or len(username) < 3:
            errors.append("Nama pengguna mestilah sekurang-kurangnya 3 aksara.")
        if not email or "@" not in email:
            errors.append("E-mel yang sah diperlukan.")
        if len(password) < 6:
            errors.append("Kata laluan mestilah sekurang-kurangnya 6 aksara.")
        if password != confirm:
            errors.append("Kata laluan tidak sepadan.")
        if User.query.filter_by(email=email).first():
            errors.append("E-mel sudah didaftarkan.")
        if User.query.filter_by(username=username).first():
            errors.append("Nama pengguna telah digunakan.")
        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template("register.html", ref_code=submitted_ref)

        user = User(username=username, email=email, saldo=Decimal('0.00'), preferred_currency="MYR")
        user.set_password(password)
        user.ensure_referral_code()

        if submitted_ref:
            referrer = User.query.filter_by(referral_code=submitted_ref).first()
            if referrer:
                user.referred_by_id = referrer.id
                logger.info(f"User {email} referred by {referrer.email} (code: {submitted_ref})")

        db.session.add(user)
        try:
            db.session.flush()
            init_user_bonuses(user)
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Registration failed: {e}", exc_info=True)
            flash("Pendaftaran gagal. Sila cuba lagi.", "danger")
            return render_template("register.html", ref_code=submitted_ref)
        logger.info(f"New user registered: {email}")
        flash("Pendaftaran berjaya! Sila log masuk ke akaun anda.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", ref_code=ref_code)

@app.route("/logout")
def logout():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    return render_template("logout.html", user=user)

@app.route("/logout/confirm", methods=["POST"])
def logout_confirm():
    session.clear()
    flash("Anda telah berjaya log keluar.", "info")
    return redirect(url_for("login"))

# ------------------------------------------------------------
# Profile & Bank
# ------------------------------------------------------------
@app.route("/profile")
def profile():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for("login"))
    transactions = Transaction.query.filter(Transaction.user_id == user_id, Transaction.type.in_(['topup', 'withdraw']))\
        .order_by(Transaction.created_at.desc()).all()
    approved = [t for t in transactions if t.status == 'approved']
    total_deposits = sum((t.amount for t in approved if t.type == 'topup'), Decimal('0.00'))
    total_withdrawals = sum((t.amount for t in approved if t.type == 'withdraw'), Decimal('0.00'))
    metrics = trade_metrics(user_id)
    net_pl = metrics['net_pnl']
    best_trade = db.session.query(db.func.max(TradeHistory.pnl)).filter_by(user_id=user_id).scalar() or Decimal('0.00')
    return render_template("profil.html", user=user, transactions=transactions, banks=BANK_OPTIONS,
                           total_deposits=total_deposits, total_withdrawals=total_withdrawals,
                           net_pl=net_pl, best_trade=best_trade, trade_metrics=metrics)

@app.route("/update_bank", methods=["POST"])
def update_bank():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for("login"))
    bank_name = request.form.get("bank_name", "").strip()
    bank_account = request.form.get("bank_account", "").strip()
    bank_account_name = request.form.get("bank_account_name", "").strip()
    if not all([bank_name, bank_account, bank_account_name]):
        flash("Semua butiran bank diperlukan.", "danger")
    else:
        user.bank_name = bank_name
        user.bank_account = bank_account
        user.bank_account_name = bank_account_name
        kyc = user.kyc_verification or KycVerification(user_id=user.id)
        kyc.bank_account_status = 'pending'
        db.session.add(kyc)
        try:
            db.session.commit()
            flash("Maklumat bank berjaya dikemas kini.", "success")
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Bank update failed: {e}", exc_info=True)
            flash("Kemas kini gagal. Sila cuba lagi.", "danger")
    return redirect(url_for("profile"))

# ------------------------------------------------------------
# Topup
# ------------------------------------------------------------
@app.route("/topup", methods=["GET", "POST"])
@limiter.limit("20 per minute")
def topup():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for("login"))

    if request.method == "POST":
        amount = clean_decimal_input(request.form.get("amount", "0"))
        if amount <= 0:
            flash("Jumlah deposit mestilah lebih besar daripada sifar.", "danger")
            return redirect(url_for("topup"))
        if amount < Decimal('1.00'):
            flash("Deposit minimum ialah RM1.00.", "danger")
            return redirect(url_for("topup"))
        if amount > Decimal('100000.00'):
            flash("Deposit maksimum ialah RM100,000.00.", "danger")
            return redirect(url_for("topup"))

        tx = Transaction(user_id=user.id, type='topup', amount=amount,
                         description=f'Permohonan deposit: {format_currency(amount)}',
                         status='pending')
        db.session.add(tx)
        try:
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Topup request failed: {e}", exc_info=True)
            flash("Transaksi gagal. Sila cuba lagi.", "danger")
            return redirect(url_for("topup"))

        logger.info(f"Topup request: user {user.email} amount {amount} MYR")
        flash(f"Permohonan deposit berjaya dihantar. Jumlah: {format_currency(amount)}", "success")
        return redirect(url_for("profile"))

    display_currency = 'MYR'
    recent_deposits = [
        {'amount_str': format_currency(t.amount), 'created_at': t.created_at}
        for t in Transaction.query.filter_by(user_id=user.id, type='topup')
        .order_by(Transaction.created_at.desc()).limit(5).all()
    ]
    return render_template("topup.html", user=user, banks=BANK_OPTIONS,
                           min_deposit=Decimal('1.00'), recent_deposits=recent_deposits)

# ------------------------------------------------------------
# Withdraw
# ------------------------------------------------------------
@app.route("/withdraw", methods=["GET", "POST"])
@limiter.limit("20 per minute")
def withdraw():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for('login'))

    if request.method == "POST":
        kyc = user.kyc_verification
        ic_document = request.files.get('ic_document')

        if (not kyc or kyc.status in ('not_submitted', 'rejected')) and (not ic_document or not ic_document.filename):
            flash("Sila muat naik kad pengenalan (IC) anda untuk pengesahan (pengeluaran pertama memerlukan pengesahan).", "danger")
            return redirect(url_for("withdraw"))

        if ic_document and ic_document.filename:
            try:
                kyc = save_kyc_document(user, ic_document)
                flash("Dokumen pengenalan (IC) telah dimuat naik untuk pengesahan.", "info")
            except ValueError as exc:
                flash(str(exc), 'danger')
                return redirect(url_for('withdraw'))

        bank_name = request.form.get("bank_name", "").strip()
        bank_account = request.form.get("bank_account", "").strip()
        bank_account_name = request.form.get("bank_account_name", "").strip()
        if not all([bank_name, bank_account, bank_account_name]):
            flash("Semua butiran bank diperlukan.", "danger")
            return redirect(url_for("withdraw"))

        user.bank_name = bank_name
        user.bank_account = bank_account
        user.bank_account_name = bank_account_name

        if not kyc:
            kyc = KycVerification(user_id=user.id)
        if kyc.bank_account_status in ('not_submitted', 'rejected'):
            kyc.bank_account_status = 'pending'
        db.session.add(kyc)

        amount = clean_decimal_input(request.form.get("amount", "0"))
        if amount <= 0:
            flash("Jumlah pengeluaran mestilah lebih besar daripada sifar.", "danger")
            return redirect(url_for("withdraw"))
        if amount > Decimal('50000.00'):
            flash("Pengeluaran maksimum ialah RM50,000.00.", "danger")
            return redirect(url_for("withdraw"))

        user = User.query.filter_by(id=user.id).with_for_update().first()
        if not user:
            session.clear()
            return redirect(url_for("login"))
        if amount > user.saldo:
            flash("Baki akaun anda tidak mencukupi.", "danger")
            return redirect(url_for("withdraw"))

        user.saldo -= amount

        verification_status = []
        if kyc.status != 'approved':
            verification_status.append("Pengesahan akaun belum selesai")
        if kyc.bank_account_status != 'approved':
            verification_status.append("Pengesahan akaun bank belum selesai")
        desc = f"Pengeluaran ke {bank_name} {bank_account}"
        if verification_status:
            desc += f" (Menunggu: {', '.join(verification_status)})"

        tx = Transaction(user_id=user.id, type='withdraw', amount=amount,
                         description=desc, status='pending',
                         bank_name=bank_name, bank_account=bank_account,
                         bank_account_name=bank_account_name)
        db.session.add(tx)

        try:
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Withdrawal request failed: {e}", exc_info=True)
            flash("Transaksi gagal. Sila cuba lagi.", "danger")
            return redirect(url_for("withdraw"))

        logger.info(f"Withdrawal request: user {user.email} amount {amount} MYR")
        flash("Permohonan pengeluaran berjaya dihantar. Anda boleh menjejaki statusnya dalam halaman butiran.", "success")
        return redirect(url_for("public_withdrawal_detail", withdrawal_id=tx.id))

    recent = Transaction.query.filter_by(user_id=user_id, type='withdraw')\
        .order_by(Transaction.created_at.desc()).limit(5).all()
    return render_template("withdraw.html", user=user, recent_withdrawals=recent)

# ------------------------------------------------------------
# Public Withdrawal Detail & PDF  ←←← DIPERBARUI
# ------------------------------------------------------------
def can_view_transaction(tx):
    if session.get('admin'):
        return True
    return session.get('user_id') == tx.user_id

@app.route("/withdrawal/<int:withdrawal_id>")
def public_withdrawal_detail(withdrawal_id):
    withdrawal = db.get_or_404(Transaction, withdrawal_id)
    if withdrawal.type != 'withdraw':
        abort(404)
    if not can_view_transaction(withdrawal):
        abort(403)
    user = db.session.get(User, withdrawal.user_id)
    kyc = user.kyc_verification if user else None
    if not kyc:
        class DummyKyc:
            status = 'not_submitted'
            bank_account_status = 'not_submitted'
        kyc = DummyKyc()
    return render_template("withdrawal_detail.html", withdrawal=withdrawal, kyc=kyc, user=user)


@app.route("/withdrawal/<int:withdrawal_id>/pdf")
def download_withdrawal_pdf(withdrawal_id):
    """
    Generate a broker-grade professional PDF voucher.
    Menggunakan modul pdf_generator (ReportLab).
    """
    withdrawal = db.get_or_404(Transaction, withdrawal_id)
    if withdrawal.type != 'withdraw':
        abort(404)
    if not can_view_transaction(withdrawal):
        abort(403)

    user = db.session.get(User, withdrawal.user_id)
    kyc = user.kyc_verification if user else None

    # Coba cari logo lokal (jika SYSTEM_SETTINGS punya site_logo lokal)
    logo_path = None
    try:
        logo_url = SYSTEM_SETTINGS.get('site_logo')
        if logo_url:
            # Kalau site_logo itu path lokal 'static/uploads/xxx.png'
            if '/static/' in logo_url:
                rel = logo_url.split('/static/', 1)[1]
                candidate = os.path.join(app.static_folder, rel)
                if os.path.exists(candidate):
                    logo_path = candidate
    except Exception:
        logo_path = None

    # Public verification URL untuk QR
    try:
        verify_url = url_for('public_withdrawal_detail',
                             withdrawal_id=withdrawal.id,
                             _external=True)
    except Exception:
        verify_url = ''

    try:
        pdf_bytes = generate_professional_voucher(
            withdrawal=withdrawal,
            user=user,
            kyc=kyc,
            site=SYSTEM_SETTINGS,
            verify_url=verify_url,
            logo_path=logo_path,
        )
    except Exception as e:
        logger.error(f"Failed to generate PDF voucher for withdrawal {withdrawal.id}: {e}", exc_info=True)
        flash("Gagal menjana PDF voucher. Sila cuba lagi.", "danger")
        return redirect(url_for('public_withdrawal_detail', withdrawal_id=withdrawal.id))

    filename = f"Voucher_WD-{withdrawal.id:06d}_{utc_now().strftime('%Y%m%d')}.pdf"
    response = make_response(pdf_bytes)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename="{filename}"'
    response.headers['Cache-Control'] = 'no-store'
    return response

# ------------------------------------------------------------
# Trade
# ------------------------------------------------------------
@app.route("/trade", methods=["GET", "POST"])
@limiter.limit("30 per minute")
def trade():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for("login"))

    if request.method == "POST":
        amount = clean_decimal_input(request.form.get("amount", "0"))
        try:
            leverage = int(request.form.get("leverage", "1"))
        except (ValueError, TypeError):
            flash("Invalid leverage value.", "danger")
            return redirect(url_for("trade"))

        trade_type = request.form.get("type", "buy").lower()
        symbol = request.form.get("symbol", "BTC/USD")

        if trade_type not in ("buy", "sell"):
            flash("Arah dagangan tidak sah.", "danger")
            return redirect(url_for("trade"))
        if symbol not in TRADE_SYMBOLS:
            flash("Simbol dagangan tidak sah.", "danger")
            return redirect(url_for("trade"))
        if leverage < 1 or leverage > MAX_LEVERAGE:
            flash(f"Leveraj mestilah antara 1x dan {MAX_LEVERAGE}x.", "danger")
            return redirect(url_for("trade"))
        if amount <= 0:
            flash("Jumlah dagangan mestilah lebih besar daripada sifar.", "danger")
            return redirect(url_for("trade"))

        user = User.query.filter_by(id=user.id).with_for_update().first()
        if not user:
            session.clear()
            return redirect(url_for("login"))
        if amount > user.saldo:
            flash("Baki akaun anda tidak mencukupi.", "danger")
            return redirect(url_for("trade"))

        winrate_prob = user.custom_winrate if user.custom_winrate is not None else 50
        winrate_prob = max(0, min(100, int(winrate_prob)))
        is_win = (random.random() * 100) < winrate_prob
        pnl = (amount * leverage * (Decimal('0.1') if is_win else Decimal('-0.1'))).quantize(Decimal('0.01'))
        pnl = max(pnl, -user.saldo)

        user.saldo += pnl
        db.session.add(TradeHistory(
            user_id=user.id, source='system', symbol=symbol, direction=trade_type,
            opened_at=utc_now(), closed_at=utc_now(), volume=amount,
            pnl=pnl, notes=f'System trade at {leverage}x leverage'
        ))
        try:
            db.session.commit()
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Trade execution failed: {e}", exc_info=True)
            flash("Dagangan gagal. Sila cuba lagi.", "danger")
            return redirect(url_for("trade"))

        result = "untung" if is_win else "rugi"
        flash(f"Dagangan {result}! P&L: {format_currency(pnl)}.", "success" if is_win else "danger")
        return redirect(url_for("trade"))

    recent_trades = TradeHistory.query.filter_by(user_id=user.id)\
        .order_by(TradeHistory.closed_at.desc()).limit(10).all()
    return render_template("trade.html", user=user, trade_symbols=TRADE_SYMBOLS,
                           max_leverage=MAX_LEVERAGE, recent_trades=recent_trades, banks=BANK_OPTIONS)

# ------------------------------------------------------------
# Settings / Profile Update
# ------------------------------------------------------------
@app.route("/settings", methods=["GET", "POST"])
def settings():
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for("login"))

    if request.method == "GET":
        return redirect(url_for("profile"))

    username = request.form.get("username", "").strip()
    email = request.form.get("email", "").strip().lower()
    current_pw = request.form.get("current_password", "")
    new_pw = request.form.get("new_password", "")
    confirm_pw = request.form.get("confirm_password", "")
    phone = request.form.get("phone", "").strip()

    if not username or not email:
        flash("Nama pengguna dan e-mel diperlukan.", "danger")
        return redirect(url_for("profile"))

    if User.query.filter(User.username == username, User.id != user.id).first():
        flash("Nama pengguna telah digunakan.", "danger")
        return redirect(url_for("profile"))
    if User.query.filter(User.email == email, User.id != user.id).first():
        flash("E-mel sudah didaftarkan.", "danger")
        return redirect(url_for("profile"))

    user.username = username
    user.email = email
    user.phone = phone
    user.preferred_currency = "MYR"

    if current_pw or new_pw or confirm_pw:
        if not user.check_password(current_pw):
            flash("Kata laluan semasa tidak betul.", "danger")
            return redirect(url_for("profile"))
        if len(new_pw) < 6:
            flash("Kata laluan baru mestilah sekurang-kurangnya 6 aksara.", "danger")
            return redirect(url_for("profile"))
        if new_pw != confirm_pw:
            flash("Kata laluan baru tidak sepadan.", "danger")
            return redirect(url_for("profile"))
        user.set_password(new_pw)
        flash("Kata laluan berjaya dikemas kini.", "success")

    bank_name = request.form.get("bank_name", "").strip()
    bank_account = request.form.get("bank_account", "").strip()
    bank_account_name = request.form.get("bank_account_name", "").strip()
    if bank_name:
        user.bank_name = bank_name
    if bank_account:
        user.bank_account = bank_account
    if bank_account_name:
        user.bank_account_name = bank_account_name

    if 'profile_picture' in request.files:
        file = request.files['profile_picture']
        if file and validate_image(file):
            ext = file.filename.rsplit('.', 1)[1].lower()
            filename = secure_filename(f"user_{user_id}_{int(utc_now().timestamp())}.{ext}")
            filepath = os.path.join(app.config['PROFILE_UPLOAD_FOLDER'], filename)
            file.save(filepath)
            user.profile_picture = url_for('static', filename=f'uploads/profiles/{filename}')
        elif file and file.filename:
            flash("Fail imej tidak sah. Format dibenarkan: PNG, JPG, SVG.", "warning")

    try:
        db.session.commit()
        flash("Profil berjaya dikemas kini.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Profile update failed: {e}", exc_info=True)
        flash("Kemas kini profil gagal. Sila cuba lagi.", "danger")
        return redirect(url_for("profile"))

    return redirect(url_for("profile"))

# ------------------------------------------------------------
# History & KYC
# ------------------------------------------------------------
def trade_metrics(user_id):
    trades = TradeHistory.query.filter_by(user_id=user_id).all()
    wins = sum(1 for t in trades if t.pnl > 0)
    losses = sum(1 for t in trades if t.pnl < 0)
    breakeven = len(trades) - wins - losses
    decisive = wins + losses
    custom_trades = [t for t in trades if t.source == 'admin']
    custom_wins = sum(1 for t in custom_trades if t.pnl > 0)
    custom_losses = sum(1 for t in custom_trades if t.pnl < 0)
    custom_decisive = custom_wins + custom_losses
    return {
        'total': len(trades), 'wins': wins, 'losses': losses, 'breakeven': breakeven,
        'win_rate': (Decimal(wins) / Decimal(decisive) * Decimal('100')) if decisive else Decimal('0'),
        'net_pnl': sum((t.pnl for t in trades), Decimal('0.00')),
        'custom_total': len(custom_trades), 'custom_wins': custom_wins, 'custom_losses': custom_losses,
        'custom_breakeven': len(custom_trades) - custom_wins - custom_losses,
        'custom_win_rate': (Decimal(custom_wins) / Decimal(custom_decisive) * Decimal('100')) if custom_decisive else Decimal('0'),
        'custom_net_pnl': sum((t.pnl for t in custom_trades), Decimal('0.00')),
    }

@app.route('/history/trades')
def trade_history():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    query = TradeHistory.query.filter_by(user_id=user_id)
    symbol = request.args.get('symbol', '').strip()
    direction = request.args.get('direction', '').strip()
    outcome = request.args.get('outcome', '').strip()
    source = request.args.get('source', '').strip()
    q = request.args.get('q', '').strip()
    if symbol:
        query = query.filter(TradeHistory.symbol == symbol)
    if direction in ('buy', 'sell'):
        query = query.filter(TradeHistory.direction == direction)
    if source in ('admin', 'system', 'legacy'):
        query = query.filter(TradeHistory.source == source)
    if outcome == 'win': query = query.filter(TradeHistory.pnl > 0)
    if outcome == 'loss': query = query.filter(TradeHistory.pnl < 0)
    if outcome == 'breakeven': query = query.filter(TradeHistory.pnl == 0)
    if q:
        query = query.filter(db.or_(TradeHistory.symbol.ilike(f'%{q}%'), TradeHistory.notes.ilike(f'%{q}%')))
    filtered_metrics = trade_metrics(user_id)
    page = max(1, request.args.get('page', 1, type=int) or 1)
    pagination = query.order_by(TradeHistory.closed_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('trade_history.html', trades=pagination.items, pagination=pagination,
                           metrics=filtered_metrics, filters=request.args, symbols=TRADE_SYMBOLS)

@app.route('/history/funds')
def fund_history():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    query = Transaction.query.filter(Transaction.user_id == user_id, Transaction.type.in_(['topup', 'withdraw']))
    tx_type, status, q = request.args.get('type', ''), request.args.get('status', ''), request.args.get('q', '').strip()
    if tx_type in ('topup', 'withdraw'): query = query.filter_by(type=tx_type)
    if status in ('pending', 'approved', 'rejected'): query = query.filter_by(status=status)
    if q: query = query.filter(db.or_(Transaction.description.ilike(f'%{q}%'), db.cast(Transaction.id, db.String).ilike(f'%{q}%')))
    page = max(1, request.args.get('page', 1, type=int) or 1)
    pagination = query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('fund_history.html', transactions=pagination.items, pagination=pagination, filters=request.args)

@app.route('/verification', methods=['GET', 'POST'])
def verification():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = db.session.get(User, user_id)
    if not user:
        session.clear()
        return redirect(url_for('login'))
    if request.method == 'POST':
        try:
            save_kyc_document(user, request.files.get('ic_document'))
            db.session.commit()
            flash('IC submitted for verification.', 'success')
        except ValueError as exc:
            flash(str(exc), 'danger')
        except SQLAlchemyError:
            db.session.rollback()
            flash('Could not submit verification document.', 'danger')
        return redirect(url_for('verification'))
    return render_template('verification.html', user=user, kyc=user.kyc_verification)

# ------------------------------------------------------------
# Bonus, Referral & Forum
# ------------------------------------------------------------
def init_user_bonuses(user):
    campaigns = BonusCampaign.query.filter_by(is_active=True).all()
    for camp in campaigns:
        existing = UserBonus.query.filter_by(user_id=user.id, campaign_id=camp.id).first()
        if not existing:
            status = 'ready' if camp.bonus_type == 'welcome' else 'locked'
            progress = 1 if camp.bonus_type == 'welcome' else 0
            ub = UserBonus(user_id=user.id, campaign_id=camp.id, title=camp.title,
                           description=camp.description, amount=camp.amount,
                           status=status, progress=progress, target=camp.target)
            db.session.add(ub)

def sync_user_bonuses(user):
    init_user_bonuses(user)
    ref_count = user.direct_referrals.count()
    has_deposit = Transaction.query.filter_by(user_id=user.id, type='topup', status='approved').first() is not None

    for ub in UserBonus.query.filter_by(user_id=user.id).all():
        if ub.status == 'locked' and ub.campaign:
            if ub.campaign.bonus_type == 'referral_milestone':
                ub.progress = ref_count
                if ub.progress >= ub.target:
                    ub.status = 'ready'
            elif ub.campaign.bonus_type == 'deposit' and has_deposit:
                ub.progress = 1
                ub.status = 'ready'
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()

def process_referral_and_bonus_for_deposit(tx, user):
    rate_l1 = Decimal(str(SYSTEM_SETTINGS.get('referral_level1_rate', 10.0)))
    rate_l2 = Decimal(str(SYSTEM_SETTINGS.get('referral_level2_rate', 3.0)))
    rate_l3 = Decimal(str(SYSTEM_SETTINGS.get('referral_level3_rate', 1.0)))

    if user.referred_by_id:
        upline1 = db.session.get(User, user.referred_by_id)
        if upline1 and upline1.is_active:
            comm1 = (tx.amount * (rate_l1 / Decimal('100'))).quantize(Decimal('0.01'))
            if comm1 > 0:
                upline1.saldo += comm1
                db.session.add(ReferralCommission(referrer_id=upline1.id, downline_id=user.id,
                                                  level=1, rate=rate_l1, source_amount=tx.amount,
                                                  amount=comm1, status='paid', source_tx_id=tx.id))
                db.session.add(Transaction(user_id=upline1.id, type='topup', amount=comm1,
                                           description=f"Komisen Rujukan Tahap 1 ({rate_l1}%) daripada deposit {user.username}",
                                           status='approved'))
                sync_user_bonuses(upline1)

            if upline1.referred_by_id:
                upline2 = db.session.get(User, upline1.referred_by_id)
                if upline2 and upline2.is_active:
                    comm2 = (tx.amount * (rate_l2 / Decimal('100'))).quantize(Decimal('0.01'))
                    if comm2 > 0:
                        upline2.saldo += comm2
                        db.session.add(ReferralCommission(referrer_id=upline2.id, downline_id=user.id,
                                                          level=2, rate=rate_l2, source_amount=tx.amount,
                                                          amount=comm2, status='paid', source_tx_id=tx.id))
                        db.session.add(Transaction(user_id=upline2.id, type='topup', amount=comm2,
                                                   description=f"Komisen Rujukan Tahap 2 ({rate_l2}%) daripada deposit {user.username}",
                                                   status='approved'))

                    if upline2.referred_by_id:
                        upline3 = db.session.get(User, upline2.referred_by_id)
                        if upline3 and upline3.is_active:
                            comm3 = (tx.amount * (rate_l3 / Decimal('100'))).quantize(Decimal('0.01'))
                            if comm3 > 0:
                                upline3.saldo += comm3
                                db.session.add(ReferralCommission(referrer_id=upline3.id, downline_id=user.id,
                                                                  level=3, rate=rate_l3, source_amount=tx.amount,
                                                                  amount=comm3, status='paid', source_tx_id=tx.id))
                                db.session.add(Transaction(user_id=upline3.id, type='topup', amount=comm3,
                                                           description=f"Komisen Rujukan Tahap 3 ({rate_l3}%) daripada deposit {user.username}",
                                                           status='approved'))

    sync_user_bonuses(user)

@app.route('/bonus')
def bonus():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = db.session.get(User, user_id)
    if not user:
        return redirect(url_for('login'))

    sync_user_bonuses(user)

    bonuses = UserBonus.query.filter_by(user_id=user.id).order_by(UserBonus.created_at.desc()).all()
    ready_bonuses = [b for b in bonuses if b.status == 'ready']
    locked_bonuses = [b for b in bonuses if b.status == 'locked']
    claimed_bonuses = [b for b in bonuses if b.status == 'claimed']

    total_claimed = sum((b.amount for b in claimed_bonuses), Decimal('0.00'))
    total_ready = sum((b.amount for b in ready_bonuses), Decimal('0.00'))

    return render_template('bonus.html', user=user, ready_bonuses=ready_bonuses,
                           locked_bonuses=locked_bonuses, claimed_bonuses=claimed_bonuses,
                           total_claimed=total_claimed, total_ready=total_ready)

@app.route('/bonus/claim/<int:bonus_id>', methods=['POST'])
def claim_bonus(bonus_id):
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = User.query.filter_by(id=user_id).with_for_update().first()
    if not user:
        return redirect(url_for('login'))
    ub = UserBonus.query.filter_by(id=bonus_id, user_id=user.id).with_for_update().first_or_404()

    if ub.status != 'ready':
        flash("Bonus ini belum sedia dituntut atau telah pun dituntut.", "warning")
        return redirect(url_for('bonus'))

    user.saldo += ub.amount
    ub.status = 'claimed'
    ub.claimed_at = utc_now()

    db.session.add(Transaction(user_id=user.id, type='topup', amount=ub.amount,
                               description=f"Tuntutan Ganjaran Bonus: {ub.title}",
                               status='approved'))

    try:
        db.session.commit()
        flash(f"Tahniah! Bonus {format_currency(ub.amount)} berjaya dituntut dan dimasukkan ke baki dagangan anda!", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to claim bonus: {e}", exc_info=True)
        flash("Ralat berlaku semasa menuntut bonus. Sila cuba lagi.", "danger")

    return redirect(url_for('bonus'))

@app.route('/bonus/claim_all', methods=['POST'])
def claim_all_bonuses():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = User.query.filter_by(id=user_id).with_for_update().first()
    if not user:
        return redirect(url_for('login'))
    ready_bonuses = UserBonus.query.filter_by(user_id=user.id, status='ready').with_for_update().all()
    if not ready_bonuses:
        flash("Tiada bonus yang sedia dituntut pada masa ini.", "info")
        return redirect(url_for('bonus'))

    total_claimed = Decimal('0.00')
    for ub in ready_bonuses:
        user.saldo += ub.amount
        ub.status = 'claimed'
        ub.claimed_at = utc_now()
        total_claimed += ub.amount
        db.session.add(Transaction(user_id=user.id, type='topup', amount=ub.amount,
                                   description=f"Tuntutan Ganjaran Bonus: {ub.title}",
                                   status='approved'))

    try:
        db.session.commit()
        flash(f"Semua bonus sedia dituntut ({format_currency(total_claimed)}) berjaya dimasukkan ke baki akaun anda!", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to claim all bonuses: {e}", exc_info=True)
        flash("Gagal menuntut semua bonus. Sila cuba lagi.", "danger")

    return redirect(url_for('bonus'))

@app.route('/referral')
def referral():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = db.session.get(User, user_id)
    if not user:
        return redirect(url_for('login'))

    user.ensure_referral_code()
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()

    downlines = user.get_downlines_by_level()
    rate_l1 = SYSTEM_SETTINGS.get('referral_level1_rate', 10.0)
    rate_l2 = SYSTEM_SETTINGS.get('referral_level2_rate', 3.0)
    rate_l3 = SYSTEM_SETTINGS.get('referral_level3_rate', 1.0)

    comm_l1 = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(referrer_id=user.id, level=1, status='paid').scalar() or Decimal('0.00')
    comm_l2 = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(referrer_id=user.id, level=2, status='paid').scalar() or Decimal('0.00')
    comm_l3 = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(referrer_id=user.id, level=3, status='paid').scalar() or Decimal('0.00')
    total_commission = comm_l1 + comm_l2 + comm_l3

    recent_commissions = ReferralCommission.query.filter_by(referrer_id=user.id).order_by(ReferralCommission.created_at.desc()).limit(15).all()

    referral_link = url_for('register', ref=user.referral_code, _external=True)

    return render_template('referral.html', user=user, referral_link=referral_link,
                           downlines=downlines, rate_l1=rate_l1, rate_l2=rate_l2, rate_l3=rate_l3,
                           comm_l1=comm_l1, comm_l2=comm_l2, comm_l3=comm_l3,
                           total_commission=total_commission, recent_commissions=recent_commissions)

@app.route('/referral/downlines/<int:level>')
def referral_downlines(level):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({'success': False, 'error': 'User not found'}), 404

    downlines = user.get_downlines_by_level()
    target_users = downlines.get(f'level{level}', [])

    def mask_str(s):
        if not s:
            return '—'
        if len(s) <= 4:
            return s[0] + '***'
        return s[:3] + '***' + s[-2:]

    data = []
    for u in target_users:
        total_dep = db.session.query(db.func.sum(Transaction.amount)).filter_by(user_id=u.id, type='topup', status='approved').scalar() or Decimal('0.00')
        comm_from_u = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(referrer_id=user.id, downline_id=u.id).scalar() or Decimal('0.00')
        data.append({
            'username': mask_str(u.username),
            'phone': mask_str(u.phone or u.email.split('@')[0]),
            'joined_at': u.created_at.strftime('%d %b %Y') if u.created_at else '—',
            'is_active': u.is_active,
            'total_deposit': format_currency(total_dep),
            'commission_earned': format_currency(comm_from_u)
        })

    return jsonify({'success': True, 'level': level, 'count': len(data), 'members': data})

@app.route('/education')
@app.route('/edukasi')
def education():
    user_id = session.get('user_id')
    user = db.session.get(User, user_id) if user_id else None
    return render_template('education.html', user=user)

@app.route('/forum')
def forum():
    user_id = session.get('user_id')
    period = request.args.get('period', 'all')
    q = request.args.get('q', '').strip()

    query = ForumPost.query.filter_by(status='approved')

    now = utc_now()
    if period == 'today':
        query = query.filter(ForumPost.created_at >= now - timedelta(days=1))
    elif period == 'week':
        query = query.filter(ForumPost.created_at >= now - timedelta(days=7))
    elif period == 'month':
        query = query.filter(ForumPost.created_at >= now - timedelta(days=30))

    if q:
        query = query.filter(db.or_(
            ForumPost.title.ilike(f'%{q}%'),
            ForumPost.content.ilike(f'%{q}%'),
            ForumPost.bank_name.ilike(f'%{q}%')
        ))

    posts = query.order_by(ForumPost.is_pinned.desc(), ForumPost.created_at.desc()).all()

    user_liked_ids = set()
    if user_id:
        user_likes = ForumLike.query.filter_by(user_id=user_id).all()
        user_liked_ids = {like.post_id for like in user_likes}

    total_proofs = ForumPost.query.filter_by(status='approved').count()
    total_paid_out = db.session.query(db.func.sum(ForumPost.amount)).filter_by(status='approved').scalar() or Decimal('0.00')
    contributors_count = db.session.query(db.func.count(db.distinct(ForumPost.user_id))).filter_by(status='approved').scalar() or 0

    return render_template('forum.html', posts=posts, period=period, q=q,
                           user_liked_ids=user_liked_ids, total_proofs=total_proofs,
                           total_paid_out=total_paid_out, contributors_count=contributors_count)

@app.route('/forum/post/create', methods=['POST'])
def forum_create_post():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
    user = db.session.get(User, user_id)

    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    bank_name = request.form.get('bank_name', '').strip()
    amount = clean_decimal_input(request.form.get('amount', '0'))

    if not title:
        flash("Tajuk bukti pengeluaran mesti diisi.", "danger")
        return redirect(url_for('forum'))

    image_url = ''
    if 'proof_image' in request.files:
        file = request.files['proof_image']
        if file and validate_image(file):
            ext = file.filename.rsplit('.', 1)[1].lower()
            filename = secure_filename(f"proof_{user.id}_{int(utc_now().timestamp())}_{os.urandom(4).hex()}.{ext}")
            filepath = os.path.join(app.config['FORUM_UPLOAD_FOLDER'], filename)
            file.save(filepath)
            image_url = url_for('static', filename=f'uploads/forum/{filename}')

    auto_approve = SYSTEM_SETTINGS.get('forum_auto_approve', True)
    status = 'approved' if auto_approve else 'pending'

    post = ForumPost(user_id=user.id, title=title, content=content, amount=amount,
                     bank_name=bank_name or (user.bank_name or 'Bank Transfer'),
                     image_url=image_url, status=status)
    db.session.add(post)
    try:
        db.session.commit()
        if auto_approve:
            flash("Bukti pengeluaran anda berjaya dikongsi ke forum komuniti!", "success")
        else:
            flash("Bukti pengeluaran berjaya dihantar dan sedang dalam giliran semakan pentadbir.", "info")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to post to forum: {e}", exc_info=True)
        flash("Gagal memuat naik bukti pengeluaran. Sila cuba lagi.", "danger")

    return redirect(url_for('forum'))

@app.route('/forum/post/<int:post_id>/like', methods=['POST'])
def forum_toggle_like(post_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Sila log masuk terlebih dahulu.'}), 401

    post = db.get_or_404(ForumPost, post_id)
    like = ForumLike.query.filter_by(post_id=post.id, user_id=user_id).first()

    if like:
        db.session.delete(like)
        post.likes_count = max(0, (post.likes_count or 1) - 1)
        liked = False
    else:
        db.session.add(ForumLike(post_id=post.id, user_id=user_id))
        post.likes_count = (post.likes_count or 0) + 1
        liked = True

    try:
        db.session.commit()
        return jsonify({'success': True, 'liked': liked, 'likes_count': post.likes_count})
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Toggle like error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': 'Database error'}), 500

@app.route('/forum/post/<int:post_id>/comment', methods=['POST'])
def forum_add_comment(post_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("Sila log masuk terlebih dahulu untuk memberi komen.", "warning")
        return redirect(url_for('login'))

    post = db.get_or_404(ForumPost, post_id)
    content = request.form.get('content', '').strip()
    if not content:
        flash("Komen tidak boleh kosong.", "warning")
        return redirect(url_for('forum'))

    db.session.add(ForumComment(post_id=post.id, user_id=user_id, content=content[:500]))
    try:
        db.session.commit()
        flash("Komen anda berjaya dihantar!", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to add comment: {e}", exc_info=True)
        flash("Gagal menambah komen.", "danger")

    return redirect(url_for('forum') + f"#post-{post_id}")

# ------------------------------------------------------------
# Admin Routes
# ------------------------------------------------------------
@app.route("/admin/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email, role='admin').first()
        if user and user.is_active and user.check_password(password):
            regenerate_session()
            session["admin"] = True
            session["admin_id"] = user.id
            session["admin_name"] = user.username
            logger.info(f"Admin {email} logged in.")
            flash("Admin login successful.", "success")
            return redirect(url_for("admin_dashboard"))
        logger.warning(f"Failed admin login attempt for {email} from {request.remote_addr}")
        flash("Invalid admin credentials.", "danger")
    return render_template("admin_login.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_balance = db.session.query(db.func.sum(User.saldo)).scalar() or Decimal('0.00')
    pending_topup = Transaction.query.filter_by(type='topup', status='pending').count()
    pending_withdraw = Transaction.query.filter_by(type='withdraw', status='pending').count()
    pending_txs = Transaction.query.filter_by(status='pending').order_by(Transaction.created_at.desc()).limit(5).all()
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    return render_template("dashboard_admin.html", total_users_val=total_users,
                           active_users_val=active_users, total_balance_val=total_balance,
                           pending_topup_val=pending_topup, pending_withdraw_val=pending_withdraw,
                           total_pending=pending_topup+pending_withdraw,
                           pending_transactions=pending_txs, recent_users=recent_users)

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None); session.pop("admin_id", None); session.pop("admin_name", None)
    flash("Admin logged out.", "info")
    return redirect(url_for("admin_login"))

@app.route("/admin/users")
@admin_required
def admin_users():
    query = User.query
    search = request.args.get('q', '').strip()
    role_filter = request.args.get('role', '').strip()
    status_filter = request.args.get('status', '').strip()
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(User.username.ilike(like), User.email.ilike(like)))
    if role_filter in ('user', 'admin'):
        query = query.filter(User.role == role_filter)
    if status_filter in ('active', 'inactive'):
        query = query.filter(User.is_active == (status_filter == 'active'))
    page = request.args.get('page', 1, type=int) or 1
    per_page = SYSTEM_SETTINGS.get('items_per_page', 25)
    try:
        per_page = max(5, min(200, int(per_page)))
    except (TypeError, ValueError):
        per_page = 25
    pagination = query.order_by(User.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    return render_template("admin_users.html", users=pagination.items, pagination=pagination,
                           search=search, role_filter=role_filter, status_filter=status_filter)

@app.route("/admin/transactions")
@admin_required
def admin_transactions():
    query = Transaction.query
    type_filter = request.args.get('type', '').strip()
    status_filter = request.args.get('status', '').strip()
    if type_filter in ('topup', 'withdraw'):
        query = query.filter(Transaction.type == type_filter)
    if status_filter in ('pending', 'approved', 'rejected'):
        query = query.filter(Transaction.status == status_filter)
    page = request.args.get('page', 1, type=int) or 1
    per_page = SYSTEM_SETTINGS.get('items_per_page', 25)
    try:
        per_page = max(5, min(200, int(per_page)))
    except (TypeError, ValueError):
        per_page = 25
    pagination = query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    total_vol = db.session.query(db.func.sum(Transaction.amount)).filter(Transaction.status == 'approved').scalar() or Decimal('0.00')
    return render_template("admin_transactions.html", transactions=pagination.items, pagination=pagination,
                           type_filter=type_filter, status_filter=status_filter, total_vol=total_vol)

def _trade_form_values(form):
    try:
        local_tz = get_local_tz()
        def parse_local_dt(raw):
            if not raw:
                return None
            naive = datetime.strptime(raw, '%Y-%m-%dT%H:%M')
            return naive.replace(tzinfo=local_tz).astimezone(timezone.utc).replace(tzinfo=None)
        values = {
            'symbol': form.get('symbol', '').strip().upper(),
            'direction': form.get('direction', '').strip().lower(),
            'volume': clean_decimal_input(form.get('volume', '0')),
            'entry_price': clean_decimal_input(form.get('entry_price', '0')),
            'exit_price': clean_decimal_input(form.get('exit_price', '0')),
            'pnl': clean_decimal_input(form.get('pnl', '0')),
            'commission': clean_decimal_input(form.get('commission', '0')),
            'swap': clean_decimal_input(form.get('swap', '0')),
            'fee': clean_decimal_input(form.get('fee', '0')),
            'notes': form.get('notes', '').strip()[:500],
            'opened_at': parse_local_dt(form.get('opened_at')),
            'closed_at': parse_local_dt(form.get('closed_at')) or utc_now(),
        }
    except (InvalidOperation, ValueError):
        raise ValueError('Trade numbers or dates are invalid.')
    if (not values['symbol'] or values['direction'] not in ('buy', 'sell') or values['volume'] < 0
            or values['entry_price'] < 0 or values['exit_price'] < 0
            or values['commission'] < 0 or values['swap'] < 0 or values['fee'] < 0):
        raise ValueError('Symbol, direction, and non-negative volume are required.')
    return values

def trade_snapshot(trade):
    return {
        'symbol': trade.symbol, 'direction': trade.direction,
        'opened_at': trade.opened_at.isoformat() if trade.opened_at else None,
        'closed_at': trade.closed_at.isoformat() if trade.closed_at else None,
        'volume': str(trade.volume), 'entry_price': str(trade.entry_price) if trade.entry_price is not None else None,
        'exit_price': str(trade.exit_price) if trade.exit_price is not None else None,
        'pnl': str(trade.pnl), 'commission': str(trade.commission),
        'swap': str(trade.swap), 'fee': str(trade.fee), 'notes': trade.notes,
        'source': trade.source,
    }

@app.route('/admin/trades', methods=['GET', 'POST'])
@admin_required
def admin_trades():
    if request.method == 'POST':
        try:
            user_id = int(request.form.get('user_id', '0'))
            nominal = clean_decimal_input(request.form.get('nominal', '0'))
            target_win = clean_decimal_input(request.form.get('target_win', '45000'))
            if nominal <= 0:
                raise ValueError('Modal (nominal) must be greater than zero.')
            if target_win <= 0:
                raise ValueError('Target win must be greater than zero.')

            user = User.query.filter_by(id=user_id, role='user').with_for_update().first()
            if not user:
                raise ValueError('Select an active user account.')

            winrate = user.custom_winrate if user.custom_winrate is not None else 50
            winrate = max(0, min(100, int(winrate)))
            batch_size = 5
            win_count = max(1, min(batch_size - 1, round(batch_size * winrate / 100)))
            loss_count = batch_size - win_count

            total_win = Decimal('0.00')
            total_loss = Decimal('0.00')
            trades_created = 0
            batch_counter = 0

            def generate_batch():
                nonlocal total_win, total_loss, trades_created, batch_counter
                if nominal > 0:
                    loss_fraction = Decimal('0.20')
                    total_loss_batch = -(abs(nominal) * loss_fraction).quantize(Decimal('0.01'))
                    total_win_batch = nominal - total_loss_batch
                else:
                    win_fraction = Decimal('0.15')
                    total_win_batch = (abs(nominal) * win_fraction).quantize(Decimal('0.01'))
                    total_loss_batch = nominal - total_win_batch

                each_loss = (total_loss_batch / loss_count).quantize(Decimal('0.01'))
                each_win = (total_win_batch / win_count).quantize(Decimal('0.01'))

                pnls = [each_loss] * loss_count + [each_win] * win_count
                diff = nominal - sum(pnls, Decimal('0.00'))
                pnls[-1] += diff
                random.shuffle(pnls)

                symbol_prices = {
                    'BTC/USD': (85000, 95000), 'ETH/USD': (3200, 3800), 'XAU/USD': (2650, 2750),
                    'EUR/USD': (1.08, 1.12), 'GBP/USD': (1.28, 1.32), 'USD/JPY': (148, 152),
                }

                now = utc_now()
                for pnl in pnls:
                    symbol = random.choice(TRADE_SYMBOLS)
                    direction = random.choice(['buy', 'sell'])
                    price_range = symbol_prices.get(symbol, (100, 200))
                    entry = Decimal(str(round(random.uniform(*price_range), 8)))
                    if pnl >= 0:
                        exit_p = entry * Decimal(str(round(random.uniform(1.001, 1.015), 8)))
                    else:
                        exit_p = entry * Decimal(str(round(random.uniform(0.985, 0.999), 8)))
                    volume = Decimal(str(round(random.uniform(0.10, 5.00), 4)))

                    opened = now - timedelta(hours=random.randint(1, 23))
                    max_duration = min(6, (now - opened).total_seconds() / 3600 - 0.1)
                    duration = random.uniform(0.5, max_duration)
                    closed = opened + timedelta(hours=duration)

                    trade = TradeHistory(
                        user_id=user.id, source='admin', symbol=symbol, direction=direction,
                        volume=volume, entry_price=entry.quantize(Decimal('0.00000001')),
                        exit_price=exit_p.quantize(Decimal('0.00000001')), pnl=pnl,
                        opened_at=opened, closed_at=closed, notes=f'{direction.upper()} {symbol}'
                    )
                    db.session.add(trade)
                    db.session.flush()
                    db.session.add(TradeAuditLog(
                        trade_id=trade.id, user_id=user.id, admin_id=session.get('admin_id'),
                        action='create', after_data=json.dumps(trade_snapshot(trade))
                    ))
                    if pnl > 0: total_win += pnl
                    elif pnl < 0: total_loss += pnl
                    trades_created += 1

                user.saldo += nominal
                batch_counter += 1

            while total_win < target_win:
                generate_batch()

            db.session.commit()

            flash(
                f'Successfully generated {trades_created} trades across {batch_counter} batches. '
                f'Total wins: {format_currency(total_win)}, losses: {format_currency(abs(total_loss))}. '
                f'User {user.username} balance is now {format_currency(user.saldo)}. '
                f'(All trades are within the last 24 hours.)',
                'success'
            )
        except (ValueError, InvalidOperation, SQLAlchemyError) as exc:
            db.session.rollback()
            if isinstance(exc, ValueError):
                msg = str(exc)
            elif isinstance(exc, InvalidOperation):
                msg = 'Nominal or target win must be valid numbers.'
            else:
                msg = 'Could not create trades.'
            flash(msg, 'danger')
        return redirect(url_for('admin_trades'))

    query = TradeHistory.query
    q = request.args.get('q', '').strip()
    if q:
        query = query.join(User).filter(db.or_(User.username.ilike(f'%{q}%'), TradeHistory.symbol.ilike(f'%{q}%')))
    page = max(1, request.args.get('page', 1, type=int) or 1)
    pagination = query.order_by(TradeHistory.closed_at.desc()).paginate(page=page, per_page=20, error_out=False)
    trades = pagination.items
    user_metrics = {}
    for t in trades:
        if t.user_id not in user_metrics:
            user_metrics[t.user_id] = trade_metrics(t.user_id)
    return render_template('admin_trades.html', trades=trades, user_metrics=user_metrics,
                           users=User.query.filter_by(role='user', is_active=True).order_by(User.username).all(),
                           pagination=pagination)

def _admin_trade_return_redirect():
    target = request.form.get('return_to', 'admin_trades')
    if target == 'admin_users':
        return_user_id = request.form.get('return_user_id', '').strip()
        if return_user_id.isdigit():
            return redirect(url_for('admin_users', open_trades_user=return_user_id))
        return redirect(url_for('admin_users'))
    return redirect(url_for('admin_trades'))

@app.route('/admin/trades/<int:trade_id>/edit', methods=['POST'])
@admin_required
def admin_edit_trade(trade_id):
    trade = db.get_or_404(TradeHistory, trade_id)
    try:
        values = _trade_form_values(request.form)
        user = User.query.filter_by(id=trade.user_id).with_for_update().first()
        if not user:
            raise ValueError('Trader account no longer exists.')
        before = trade_snapshot(trade)
        old_pnl = trade.pnl
        for key, value in values.items(): setattr(trade, key, value)
        new_balance = user.saldo + trade.pnl - old_pnl
        if new_balance < 0:
            raise ValueError(f'This change would push {user.username}\'s balance below zero (would become {format_currency(new_balance)}).')
        user.saldo = new_balance
        db.session.add(TradeAuditLog(trade_id=trade.id, user_id=user.id, admin_id=session.get('admin_id'),
                                    action='update', before_data=json.dumps(before),
                                    after_data=json.dumps(trade_snapshot(trade))))
        db.session.commit()
        flash(f'Trade updated and balance adjusted. {user.username} balance is now {format_currency(new_balance)}.', 'success')
    except (ValueError, SQLAlchemyError) as exc:
        db.session.rollback()
        flash(str(exc) if isinstance(exc, ValueError) else 'Could not update trade.', 'danger')
    return _admin_trade_return_redirect()

@app.route('/admin/trades/<int:trade_id>/delete', methods=['POST'])
@admin_required
def admin_delete_trade(trade_id):
    trade = db.get_or_404(TradeHistory, trade_id)
    try:
        user = User.query.filter_by(id=trade.user_id).with_for_update().first()
        if not user:
            raise ValueError('Trader account no longer exists.')
        new_balance = user.saldo - trade.pnl
        if new_balance < 0:
            raise ValueError(f'Cannot delete: reversing this trade would push {user.username}\'s balance below zero (would become {format_currency(new_balance)}). Top up the balance first or edit the trade instead.')
        before = trade_snapshot(trade)
        user.saldo = new_balance
        db.session.add(TradeAuditLog(trade_id=trade.id, user_id=user.id, admin_id=session.get('admin_id'),
                                    action='delete', before_data=json.dumps(before)))
        db.session.delete(trade)
        db.session.commit()
        flash(f'Trade deleted and balance reversed. {user.username} balance is now {format_currency(new_balance)}.', 'success')
    except (ValueError, SQLAlchemyError) as exc:
        db.session.rollback()
        flash(str(exc) if isinstance(exc, ValueError) else 'Could not delete trade.', 'danger')
    return _admin_trade_return_redirect()

@app.route('/admin/kyc', methods=['GET', 'POST'])
@admin_required
def admin_kyc():
    global SYSTEM_SETTINGS
    if request.method == 'POST':
        default_messages = {
            'required': 'Please upload your document below. Verification is required prior to processing fund withdrawals.',
            'pending': 'Your document is under compliance review. Standard review time is under 12 hours.',
            'approved': 'Account verification is approved. Withdrawal access is enabled after bank account verification is also approved.',
            'rejected': 'Your document could not be approved. Please upload a clearer or valid document.'
        }
        default_messages.update(SYSTEM_SETTINGS.get('kyc_status_messages', {}))
        SYSTEM_SETTINGS['kyc_status_messages'] = {
            status: request.form.get(f'kyc_message_{status}', default).strip()[:500] or default
            for status, default in default_messages.items()
        }
        save_system_settings(SYSTEM_SETTINGS)
        flash('KYC status templates saved successfully.', 'success')
        return redirect(url_for('admin_kyc'))

    status = request.args.get('status', '')
    query = KycVerification.query
    if status in ('pending', 'approved', 'rejected'): query = query.filter_by(status=status)
    return render_template('admin_kyc.html', verifications=query.order_by(KycVerification.submitted_at.desc()).all(),
                           status=status, kyc_status_messages=SYSTEM_SETTINGS.get('kyc_status_messages', {}))

@app.route('/admin/kyc/<int:kyc_id>/document')
@admin_required
def admin_kyc_document(kyc_id):
    kyc = db.get_or_404(KycVerification, kyc_id)
    if not kyc.document_path or not os.path.isfile(kyc.document_path): abort(404)
    return send_file(kyc.document_path, conditional=True, as_attachment=False)

@app.route('/admin/kyc/<int:kyc_id>/<action>', methods=['POST'])
@admin_required
def admin_review_kyc(kyc_id, action):
    if action not in ('approve', 'reject'): abort(404)
    kyc = db.get_or_404(KycVerification, kyc_id)
    if not kyc.document_path: abort(400)
    kyc.status = 'approved' if action == 'approve' else 'rejected'
    kyc.rejection_note = request.form.get('note', '').strip()[:500] if action == 'reject' else ''
    kyc.reviewer_id, kyc.reviewed_at = session.get('admin_id'), utc_now()
    db.session.commit()
    flash(f'KYC {kyc.status}.', 'success')
    return redirect(url_for('admin_kyc'))

@app.route('/admin/kyc/<int:kyc_id>/bank/<action>', methods=['POST'])
@admin_required
def admin_review_bank_account(kyc_id, action):
    if action not in ('approve', 'reject'): abort(404)
    kyc = db.get_or_404(KycVerification, kyc_id)
    if not kyc.user or not all([kyc.user.bank_name, kyc.user.bank_account, kyc.user.bank_account_name]):
        abort(400)
    kyc.bank_account_status = 'approved' if action == 'approve' else 'rejected'
    if action == 'reject':
        kyc.rejection_note = request.form.get('note', '').strip()[:500]
    kyc.reviewer_id, kyc.reviewed_at = session.get('admin_id'), utc_now()
    db.session.commit()
    flash(f'Bank account verification {kyc.bank_account_status}.', 'success')
    return redirect(url_for('admin_kyc'))

@app.route("/admin/pending")
@admin_required
def admin_pending():
    txs = Transaction.query.filter_by(status='pending').order_by(Transaction.created_at.desc()).all()
    return render_template("admin_pending.html", transactions=txs)

@app.route("/admin/analytics")
@admin_required
def admin_analytics():
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_volume = db.session.query(db.func.sum(db.func.abs(TradeHistory.pnl))).scalar() or Decimal('0.00')
    total_trades = TradeHistory.query.count()
    avg_trade_size = Decimal('0.00')
    if total_trades > 0:
        avg_trade_size = total_volume / total_trades

    volume_labels, volume_data, user_activity_data = [], [], []
    for i in range(6, -1, -1):
        date = datetime.now(get_local_tz()).date() - timedelta(days=i)
        volume_labels.append(date.strftime('%a'))
        day_volume = db.session.query(db.func.sum(db.func.abs(TradeHistory.pnl)))\
            .filter(db.func.date(TradeHistory.closed_at) == date).scalar() or Decimal('0.00')
        volume_data.append(float(day_volume))
        active_users_count = db.session.query(db.func.count(db.distinct(TradeHistory.user_id)))\
            .filter(db.func.date(TradeHistory.closed_at) == date).scalar() or 0
        user_activity_data.append(active_users_count)

    top_traders = db.session.query(User.username, db.func.sum(TradeHistory.pnl).label('total_volume'))\
        .join(TradeHistory).group_by(User.id).order_by(db.func.sum(TradeHistory.pnl).desc()).limit(5).all()
    large_trades = TradeHistory.query.filter(TradeHistory.pnl >= 1000).order_by(TradeHistory.closed_at.desc()).limit(5).all()
    reports = [
        {'name': 'Monthly Trading Summary', 'type': 'Financial', 'period': 'Mar 2026', 'generated': 'Apr 1, 2026', 'status': 'Ready'},
        {'name': 'User Acquisition Report', 'type': 'Marketing', 'period': 'Q1 2026', 'generated': 'Apr 2, 2026', 'status': 'Ready'},
        {'name': 'Risk Assessment', 'type': 'Compliance', 'period': 'Weekly', 'generated': 'Apr 5, 2026', 'status': 'Ready'},
        {'name': 'Transaction Audit Log', 'type': 'Security', 'period': 'Apr 1 - Apr 7', 'generated': 'Apr 7, 2026', 'status': 'Processing'},
        {'name': 'Performance Benchmark', 'type': 'Analytics', 'period': 'YTD 2026', 'generated': 'Apr 6, 2026', 'status': 'Scheduled'}
    ]
    return render_template("admin_analytics.html", total_users=total_users, active_users=active_users,
                           total_volume=float(total_volume), total_trades=total_trades,
                           avg_trade_size=float(avg_trade_size), volume_labels=volume_labels,
                           volume_data=volume_data, user_activity_data=user_activity_data,
                           top_traders=top_traders, large_trades=large_trades, reports=reports)

@app.route("/admin/reports")
@admin_required
def admin_reports():
    reports = [{'name': 'Monthly Trading Summary', 'type': 'Financial', 'period': 'Mar 2026', 'generated': 'Apr 1, 2026', 'status': 'Ready'},
               {'name': 'User Acquisition Report', 'type': 'Marketing', 'period': 'Q1 2026', 'generated': 'Apr 2, 2026', 'status': 'Ready'},
               {'name': 'Risk Assessment', 'type': 'Compliance', 'period': 'Weekly', 'generated': 'Apr 5, 2026', 'status': 'Ready'},
               {'name': 'Transaction Audit Log', 'type': 'Security', 'period': 'Apr 1 - Apr 7', 'generated': 'Apr 7, 2026', 'status': 'Processing'},
               {'name': 'Performance Benchmark', 'type': 'Analytics', 'period': 'YTD 2026', 'generated': 'Apr 6, 2026', 'status': 'Scheduled'}]
    return render_template("admin_reports.html", reports=reports)

@app.route("/admin/toggle_user/<int:user_id>", methods=["POST"])
@admin_required
def toggle_user(user_id):
    user = db.get_or_404(User, user_id)
    if user.role == 'admin' and user.is_active:
        active_admins = User.query.filter_by(role='admin', is_active=True).count()
        if active_admins <= 1:
            flash("Cannot deactivate the last active admin account.", "danger")
            return redirect(url_for('admin_users'))
    user.is_active = not user.is_active
    try:
        db.session.commit()
        flash(f"User {user.username} {'activated' if user.is_active else 'deactivated'}.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Toggle user failed: {e}", exc_info=True)
        flash("Operation failed.", "danger")
    return redirect(url_for('admin_users'))

@app.route("/admin/users/add", methods=["POST"])
@admin_required
def admin_add_user():
    username = request.form.get("username", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    saldo = clean_decimal_input(request.form.get("saldo", "0.00"))
    role = request.form.get("role", "user")
    is_active = bool(request.form.get("is_active"))

    errors = []
    if not username or len(username) < 3:
        errors.append("Username must be at least 3 characters.")
    if not email or "@" not in email:
        errors.append("Valid email is required.")
    if not password or len(password) < 6:
        errors.append("Password must be at least 6 characters.")
    if User.query.filter_by(email=email).first():
        errors.append("Email already registered.")
    if User.query.filter_by(username=username).first():
        errors.append("Username already taken.")
    if errors:
        for err in errors:
            flash(err, "danger")
        return redirect(url_for('admin_users'))

    try:
        custom_winrate = int(request.form.get("custom_winrate", 50))
        custom_winrate = max(0, min(100, custom_winrate))
    except (ValueError, TypeError):
        custom_winrate = 50

    new_user = User(username=username, email=email, saldo=saldo, is_active=is_active,
                    role=role, preferred_currency="MYR", custom_winrate=custom_winrate)
    new_user.set_password(password)
    db.session.add(new_user)
    try:
        db.session.commit()
        logger.info(f"Admin created new user: {email}")
        flash(f"User '{username}' created successfully with {custom_winrate}% winrate.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Admin add user failed: {e}", exc_info=True)
        flash("Failed to create user.", "danger")
    return redirect(url_for('admin_users'))

@app.route("/admin/users/<int:user_id>/edit", methods=["POST"])
@admin_required
def admin_edit_user(user_id):
    user = db.get_or_404(User, user_id)
    username = request.form.get("username", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    saldo = clean_decimal_input(request.form.get("saldo", "0.00"))
    role = request.form.get("role", "user")
    is_active = bool(request.form.get("is_active"))

    errors = []
    if not username or len(username) < 3:
        errors.append("Username must be at least 3 characters.")
    if not email or "@" not in email:
        errors.append("Valid email is required.")
    if User.query.filter(User.email == email, User.id != user_id).first():
        errors.append("Email already registered by another user.")
    if User.query.filter(User.username == username, User.id != user_id).first():
        errors.append("Username already taken.")
    if errors:
        for err in errors:
            flash(err, "danger")
        return redirect(url_for('admin_users'))

    try:
        custom_winrate = int(request.form.get("custom_winrate", user.custom_winrate if user.custom_winrate is not None else 50))
        user.custom_winrate = max(0, min(100, custom_winrate))
    except (ValueError, TypeError):
        pass

    user.username = username
    user.email = email
    user.saldo = saldo
    user.role = role
    user.is_active = is_active
    user.preferred_currency = "MYR"
    if password and password.strip():
        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return redirect(url_for('admin_users'))
        user.set_password(password)
    try:
        db.session.commit()
        logger.info(f"Admin updated user: {user.email}")
        flash(f"User '{username}' updated successfully.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Admin edit user failed: {e}", exc_info=True)
        flash("Failed to update user.", "danger")
    return redirect(url_for('admin_users'))

@app.route("/admin/users/<int:user_id>/set_winrate", methods=["POST"])
@admin_required
def admin_set_user_winrate(user_id):
    user = db.get_or_404(User, user_id)
    try:
        winrate = int(request.form.get("winrate", 50))
        user.custom_winrate = max(0, min(100, winrate))
        db.session.commit()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
            return jsonify({'success': True, 'winrate': user.custom_winrate,
                            'message': f'Winrate for {user.username} set to {user.custom_winrate}%'})
        flash(f"Custom winrate for {user.username} updated to {user.custom_winrate}%.", "success")
    except (ValueError, TypeError, SQLAlchemyError) as e:
        db.session.rollback()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
            return jsonify({'success': False, 'error': str(e)}), 400
        flash("Invalid winrate value.", "danger")
    return redirect(url_for('admin_users'))

@app.route("/admin/users/<int:user_id>/trades", methods=["GET"])
@admin_required
def admin_user_trades(user_id):
    user = db.get_or_404(User, user_id)
    trades = TradeHistory.query.filter_by(user_id=user.id).order_by(TradeHistory.closed_at.desc()).all()
    data = []
    for t in trades:
        data.append({
            'id': t.id, 'symbol': t.symbol, 'direction': t.direction,
            'volume': float(t.volume),
            'entry_price': float(t.entry_price) if t.entry_price else 0.0,
            'exit_price': float(t.exit_price) if t.exit_price else 0.0,
            'pnl': float(t.pnl), 'source': t.source,
            'closed_at': (lambda dt: dt.astimezone(ZoneInfo(SYSTEM_SETTINGS.get('timezone', 'UTC'))).strftime('%Y-%m-%d %H:%M:%S') if dt else '—')(t.closed_at),
            'notes': t.notes
        })
    metrics = trade_metrics(user.id)
    return jsonify({
        'success': True,
        'user': {'id': user.id, 'username': user.username, 'email': user.email,
                 'saldo': float(user.saldo), 'custom_winrate': user.custom_winrate},
        'trades': data,
        'metrics': {
            'total': metrics['total'], 'wins': metrics['wins'], 'losses': metrics['losses'],
            'win_rate': float(metrics['win_rate']), 'net_pnl': float(metrics['net_pnl'])
        }
    })

@app.route("/admin/users/<int:user_id>/inject_trade", methods=["POST"])
@admin_required
def admin_user_inject_trade(user_id):
    user = User.query.filter_by(id=user_id).with_for_update().first()
    if not user:
        flash("User not found.", "danger")
        return redirect(url_for('admin_users'))
    try:
        values = _trade_form_values(request.form)
        trade = TradeHistory(user_id=user.id, source='admin', **values)
        if user.saldo + trade.pnl < 0:
            raise ValueError("Trade loss exceeds user available balance.")
        user.saldo += trade.pnl
        db.session.add(trade)
        db.session.flush()
        db.session.add(TradeAuditLog(trade_id=trade.id, user_id=user.id, admin_id=session.get('admin_id'),
                                    action='create', after_data=json.dumps(trade_snapshot(trade))))
        db.session.commit()
        flash(f"Custom trade for {user.username} ({trade.symbol} {trade.direction.upper()} P&L: {format_currency(trade.pnl)}) injected successfully.", "success")
    except (ValueError, SQLAlchemyError) as exc:
        db.session.rollback()
        flash(str(exc) if isinstance(exc, ValueError) else "Failed to inject custom trade.", "danger")
    return redirect(url_for('admin_users', open_trades_user=user_id))

@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    user = db.get_or_404(User, user_id)
    if user.role == 'admin':
        admin_count = User.query.filter_by(role='admin').count()
        if admin_count <= 1:
            flash("Cannot delete the last admin account.", "danger")
            return redirect(url_for('admin_users'))
    Transaction.query.filter_by(user_id=user_id).delete()
    db.session.delete(user)
    try:
        db.session.commit()
        logger.info(f"Admin deleted user: {user.email}")
        flash(f"User '{user.username}' has been deleted.", "warning")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Admin delete user failed: {e}", exc_info=True)
        flash("Failed to delete user.", "danger")
    return redirect(url_for('admin_users'))

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    global SYSTEM_SETTINGS
    if request.method == "POST":
        SYSTEM_SETTINGS['site_name'] = request.form.get('site_name', 'Global Market').strip()
        SYSTEM_SETTINGS['site_tagline'] = request.form.get('site_tagline', '').strip()
        SYSTEM_SETTINGS['default_currency'] = 'MYR'
        SYSTEM_SETTINGS['timezone'] = request.form.get('timezone', 'UTC').strip()
        SYSTEM_SETTINGS['date_format'] = request.form.get('date_format', 'Y-m-d')
        SYSTEM_SETTINGS['time_format'] = request.form.get('time_format', 'H:i')
        try:
            SYSTEM_SETTINGS['items_per_page'] = max(5, min(200, int(request.form.get('items_per_page', 25))))
        except (TypeError, ValueError):
            SYSTEM_SETTINGS['items_per_page'] = 25
        SYSTEM_SETTINGS['email_notifications'] = bool(request.form.get('email_notifications'))
        SYSTEM_SETTINGS['browser_notifications'] = bool(request.form.get('browser_notifications'))
        SYSTEM_SETTINGS['sound_alerts'] = bool(request.form.get('sound_alerts'))
        SYSTEM_SETTINGS['maintenance_mode'] = bool(request.form.get('maintenance_mode'))
        SYSTEM_SETTINGS['admin_name'] = request.form.get('admin_name', 'Administrator').strip()
        SYSTEM_SETTINGS['admin_email'] = request.form.get('admin_email', 'admin@globalmarket.com').strip()
        try:
            SYSTEM_SETTINGS['session_timeout'] = max(5, min(480, int(request.form.get('session_timeout', 60))))
        except (TypeError, ValueError):
            SYSTEM_SETTINGS['session_timeout'] = 60

        if 'telegram_bot_name' in request.form:
            SYSTEM_SETTINGS['telegram_bot_name'] = request.form.get('telegram_bot_name', '').strip().lstrip('@')
        if 'telegram_bot_token' in request.form:
            SYSTEM_SETTINGS['telegram_bot_token'] = request.form.get('telegram_bot_token', '').strip()

        if 'site_logo' in request.files:
            file = request.files['site_logo']
            if file and validate_image(file):
                ext = file.filename.rsplit('.', 1)[1].lower()
                filename = secure_filename(f"logo_{int(utc_now().timestamp())}.{ext}")
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                SYSTEM_SETTINGS['site_logo'] = url_for('static', filename=f'uploads/{filename}')
        if request.form.get('remove_logo') == 'true':
            SYSTEM_SETTINGS.pop('site_logo', None)

        save_system_settings(SYSTEM_SETTINGS)
        flash("Settings saved successfully.", "success")
        return redirect(url_for('admin_settings'))

    return render_template("setting.html",
                           admin_name=SYSTEM_SETTINGS.get('admin_name', 'Administrator'),
                           admin_email=SYSTEM_SETTINGS.get('admin_email', 'admin@globalmarket.com'),
                           logo_url=SYSTEM_SETTINGS.get('site_logo'),
                           site_name=SYSTEM_SETTINGS.get('site_name', 'Global Market'),
                           site_tagline=SYSTEM_SETTINGS.get('site_tagline', 'Professional Trading Platform'),
                           default_currency='MYR', timezone=SYSTEM_SETTINGS.get('timezone', 'UTC'),
                           date_format=SYSTEM_SETTINGS.get('date_format', 'Y-m-d'),
                           time_format=SYSTEM_SETTINGS.get('time_format', 'H:i'),
                           items_per_page=SYSTEM_SETTINGS.get('items_per_page', 25),
                           email_notifications=SYSTEM_SETTINGS.get('email_notifications', True),
                           browser_notifications=SYSTEM_SETTINGS.get('browser_notifications', False),
                           sound_alerts=SYSTEM_SETTINGS.get('sound_alerts', False),
                           maintenance_mode=SYSTEM_SETTINGS.get('maintenance_mode', False),
                           session_timeout=SYSTEM_SETTINGS.get('session_timeout', 60),
                           two_factor_enabled=SYSTEM_SETTINGS.get('two_factor_enabled', False),
                           last_login_ip=request.remote_addr,
                           last_login_time=datetime.now(ZoneInfo(SYSTEM_SETTINGS.get('timezone', 'UTC'))).strftime('%Y-%m-%d %H:%M:%S'))

@app.route("/admin/clear_cache", methods=["POST"])
@admin_required
def admin_clear_cache():
    flash("System cache cleared.", "success")
    return redirect(url_for('admin_settings'))

@app.route("/admin/reset_settings", methods=["POST"])
@admin_required
def admin_reset_settings():
    global SYSTEM_SETTINGS
    if SETTINGS_FILE.exists():
        SETTINGS_FILE.unlink()
    SYSTEM_SETTINGS = load_system_settings()
    flash("Settings reset to defaults.", "warning")
    return redirect(url_for('admin_settings'))

@app.route("/admin/transaction/<int:trans_id>/approve", methods=["POST"])
@admin_required
def approve_transaction(trans_id):
    tx = db.get_or_404(Transaction, trans_id)
    if tx.status != 'pending':
        flash(f"Transaction #{trans_id} has already been processed.", "warning")
        return redirect(url_for('admin_pending'))
    user = User.query.filter_by(id=tx.user_id).with_for_update().first()
    if not user:
        flash("Transaction owner not found.", "danger")
        return redirect(url_for('admin_pending'))
    if tx.type == 'withdraw' and (not user.kyc_verification or user.kyc_verification.status != 'approved'):
        flash('Withdrawal cannot be approved until the user IC verification is approved.', 'danger')
        return redirect(url_for('admin_pending'))
    if tx.type == 'topup':
        user.saldo += tx.amount
        process_referral_and_bonus_for_deposit(tx, user)
    tx.status = 'approved'
    tx.admin_notes = request.form.get('notes', '')
    tx.updated_at = utc_now()
    try:
        db.session.commit()
        logger.info(f"Transaction {trans_id} approved by admin.")
        flash(f"Transaction #{trans_id} approved.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Approve transaction failed: {e}", exc_info=True)
        flash("Approval failed.", "danger")
    return redirect(url_for('admin_pending'))

@app.route("/admin/transaction/<int:trans_id>/reject", methods=["POST"])
@admin_required
def reject_transaction(trans_id):
    tx = db.get_or_404(Transaction, trans_id)
    if tx.status != 'pending':
        flash(f"Transaction #{trans_id} has already been processed.", "warning")
        return redirect(url_for('admin_pending'))
    user = User.query.filter_by(id=tx.user_id).with_for_update().first()
    if not user:
        flash("Transaction owner not found.", "danger")
        return redirect(url_for('admin_pending'))
    if tx.type == 'withdraw':
        user.saldo += tx.amount
    tx.status = 'rejected'
    tx.admin_notes = request.form.get('notes', '')
    tx.updated_at = utc_now()
    try:
        db.session.commit()
        logger.info(f"Transaction {trans_id} rejected by admin.")
        flash(f"Transaction #{trans_id} rejected.", "danger")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Reject transaction failed: {e}", exc_info=True)
        flash("Rejection failed.", "danger")
    return redirect(url_for('admin_pending'))

@app.route("/admin/transactions/batch_approve", methods=["POST"])
@admin_required
def batch_approve_transactions():
    ids = request.form.getlist('transaction_ids[]')
    if not ids:
        flash("No transactions selected.", "warning")
        return redirect(url_for('admin_pending'))
    approved = 0
    for tid in ids:
        try:
            tx = db.session.get(Transaction, int(tid))
            if tx and tx.status == 'pending':
                user = db.session.get(User, tx.user_id)
                if tx.type == 'withdraw' and (not user or not user.kyc_verification or user.kyc_verification.status != 'approved'):
                    continue
                if tx.type == 'topup' and user:
                    user.saldo += tx.amount
                    process_referral_and_bonus_for_deposit(tx, user)
                tx.status = 'approved'
                tx.updated_at = utc_now()
                approved += 1
        except (ValueError, SQLAlchemyError) as e:
            logger.error(f"Batch approve error for id {tid}: {e}", exc_info=True)
    try:
        db.session.commit()
        flash(f"{approved} transaction(s) approved.", "success")
        logger.info(f"Batch approved {approved} transactions by admin.")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Batch approve commit failed: {e}", exc_info=True)
        flash("Batch approval failed.", "danger")
    return redirect(url_for('admin_pending'))

@app.route("/admin/transactions/batch_reject", methods=["POST"])
@admin_required
def batch_reject_transactions():
    ids = request.form.getlist('transaction_ids[]')
    if not ids:
        flash("No transactions selected.", "warning")
        return redirect(url_for('admin_pending'))
    rejected = 0
    for tid in ids:
        try:
            tx = db.session.get(Transaction, int(tid))
            if tx and tx.status == 'pending':
                user = db.session.get(User, tx.user_id)
                if tx.type == 'withdraw' and user:
                    user.saldo += tx.amount
                tx.status = 'rejected'
                tx.updated_at = utc_now()
                rejected += 1
        except (ValueError, SQLAlchemyError) as e:
            logger.error(f"Batch reject error for id {tid}: {e}", exc_info=True)
    try:
        db.session.commit()
        flash(f"{rejected} transaction(s) rejected.", "danger")
        logger.info(f"Batch rejected {rejected} transactions by admin.")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Batch reject commit failed: {e}", exc_info=True)
        flash("Batch rejection failed.", "danger")
    return redirect(url_for('admin_pending'))

# ------------------------------------------------------------
# Admin Bonus, Referral & Forum Moderation
# ------------------------------------------------------------
@app.route("/admin/bonuses", methods=["GET"])
@admin_required
def admin_bonuses():
    campaigns = BonusCampaign.query.order_by(BonusCampaign.created_at.desc()).all()
    user_bonuses = UserBonus.query.order_by(UserBonus.created_at.desc()).limit(100).all()
    users = User.query.filter_by(role='user', is_active=True).order_by(User.username.asc()).all()

    total_claimed_count = UserBonus.query.filter_by(status='claimed').count()
    total_claimed_amount = db.session.query(db.func.sum(UserBonus.amount)).filter_by(status='claimed').scalar() or Decimal('0.00')
    total_campaigns = len(campaigns)

    return render_template("admin_bonuses.html", campaigns=campaigns, user_bonuses=user_bonuses,
                           users=users, total_claimed_count=total_claimed_count,
                           total_claimed_amount=total_claimed_amount, total_campaigns=total_campaigns)

@app.route("/admin/bonuses/campaign/create", methods=["POST"])
@admin_required
def admin_create_bonus_campaign():
    code = request.form.get("code", "").strip().lower()
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    amount = clean_decimal_input(request.form.get("amount", "0"))
    bonus_type = request.form.get("bonus_type", "milestone")
    target = int(request.form.get("target", 1))
    min_deposit = clean_decimal_input(request.form.get("min_deposit", "0"))
    badge = request.form.get("badge", "Hot").strip()

    if not code or not title or amount <= 0:
        flash("Kode promo, judul, dan nominal bonus valid diperlukan.", "danger")
        return redirect(url_for("admin_bonuses"))

    if BonusCampaign.query.filter_by(code=code).first():
        flash("Kode promo sudah digunakan. Gunakan kode lain.", "danger")
        return redirect(url_for("admin_bonuses"))

    camp = BonusCampaign(code=code, title=title, description=description, amount=amount,
                         bonus_type=bonus_type, target=target, min_deposit=min_deposit,
                         badge=badge, is_active=True)
    db.session.add(camp)
    try:
        db.session.commit()
        flash(f"Kampanye bonus '{title}' berhasil dibuat.", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to create bonus campaign: {e}", exc_info=True)
        flash("Gagal membuat kampanye bonus.", "danger")

    return redirect(url_for("admin_bonuses"))

@app.route("/admin/bonuses/campaign/<int:campaign_id>/toggle", methods=["POST"])
@admin_required
def admin_toggle_bonus_campaign(campaign_id):
    camp = db.get_or_404(BonusCampaign, campaign_id)
    camp.is_active = not camp.is_active
    db.session.commit()
    flash(f"Kampanye '{camp.title}' status diubah menjadi {'Aktif' if camp.is_active else 'Nonaktif'}.", "success")
    return redirect(url_for("admin_bonuses"))

@app.route("/admin/bonuses/campaign/<int:campaign_id>/delete", methods=["POST"])
@admin_required
def admin_delete_bonus_campaign(campaign_id):
    camp = db.get_or_404(BonusCampaign, campaign_id)
    db.session.delete(camp)
    db.session.commit()
    flash(f"Kampanye '{camp.title}' berhasil dihapus.", "warning")
    return redirect(url_for("admin_bonuses"))

@app.route("/admin/bonuses/grant", methods=["POST"])
@admin_required
def admin_grant_bonus():
    user_id = int(request.form.get("user_id", 0))
    title = request.form.get("title", "").strip() or "Special Trader Bonus"
    amount = clean_decimal_input(request.form.get("amount", "0"))
    description = request.form.get("description", "").strip()
    direct_credit = request.form.get("direct_credit") == "true"

    user = db.get_or_404(User, user_id)
    if amount <= 0:
        flash("Nominal bonus harus lebih dari 0.", "danger")
        return redirect(url_for("admin_bonuses"))

    if direct_credit:
        user.saldo += amount
        status = 'claimed'
        claimed_at = utc_now()
        tx = Transaction(user_id=user.id, type='topup', amount=amount,
                         description=f"Direct Bonus Grant: {title}",
                         status='approved',
                         admin_notes=f"Diberikan langsung oleh admin {session.get('admin_name')}")
        db.session.add(tx)
    else:
        status = 'ready'
        claimed_at = None

    ub = UserBonus(user_id=user.id, title=title,
                   description=description or "Bonus spesial dari Admin Global Market",
                   amount=amount, status=status, progress=1, target=1, claimed_at=claimed_at)
    db.session.add(ub)

    try:
        db.session.commit()
        flash(f"Bonus {format_currency(amount)} berhasil diberikan kepada {user.username} ({'Langsung Masuk Saldo' if direct_credit else 'Siap Diklaim User'}).", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to grant bonus: {e}", exc_info=True)
        flash("Gagal memberikan bonus.", "danger")

    return redirect(url_for("admin_bonuses"))

@app.route("/admin/referrals", methods=["GET", "POST"])
@admin_required
def admin_referrals():
    global SYSTEM_SETTINGS
    if request.method == "POST":
        try:
            SYSTEM_SETTINGS['referral_level1_rate'] = float(request.form.get('referral_level1_rate', 10.0))
            SYSTEM_SETTINGS['referral_level2_rate'] = float(request.form.get('referral_level2_rate', 3.0))
            SYSTEM_SETTINGS['referral_level3_rate'] = float(request.form.get('referral_level3_rate', 1.0))
            save_system_settings(SYSTEM_SETTINGS)
            flash("Pengaturan persentase komisi referral berhasil disimpan.", "success")
        except Exception as e:
            flash(f"Gagal menyimpan pengaturan: {e}", "danger")
        return redirect(url_for('admin_referrals'))

    top_referrers = db.session.query(
        User,
        db.func.count(ReferralCommission.id).label('comm_count'),
        db.func.sum(ReferralCommission.amount).label('total_comm')
    ).join(ReferralCommission, ReferralCommission.referrer_id == User.id)\
     .group_by(User.id)\
     .order_by(db.func.sum(ReferralCommission.amount).desc())\
     .limit(10).all()

    commissions = ReferralCommission.query.order_by(ReferralCommission.created_at.desc()).limit(100).all()

    total_referral_commissions = db.session.query(db.func.sum(ReferralCommission.amount)).filter_by(status='paid').scalar() or Decimal('0.00')
    total_commission_count = ReferralCommission.query.count()
    active_referrers_count = db.session.query(db.func.count(db.distinct(User.referred_by_id))).filter(User.referred_by_id != None).scalar() or 0

    return render_template("admin_referrals.html", top_referrers=top_referrers, commissions=commissions,
                           rate_l1=SYSTEM_SETTINGS.get('referral_level1_rate', 10.0),
                           rate_l2=SYSTEM_SETTINGS.get('referral_level2_rate', 3.0),
                           rate_l3=SYSTEM_SETTINGS.get('referral_level3_rate', 1.0),
                           total_referral_commissions=total_referral_commissions,
                           total_commission_count=total_commission_count,
                           active_referrers_count=active_referrers_count)

@app.route("/admin/forum", methods=["GET"])
@admin_required
def admin_forum():
    status_filter = request.args.get('status', 'all')
    query = ForumPost.query
    if status_filter in ('pending', 'approved', 'rejected'):
        query = query.filter_by(status=status_filter)
    posts = query.order_by(ForumPost.is_pinned.desc(), ForumPost.created_at.desc()).all()
    pending_count = ForumPost.query.filter_by(status='pending').count()
    approved_count = ForumPost.query.filter_by(status='approved').count()
    auto_approve = SYSTEM_SETTINGS.get('forum_auto_approve', True)
    return render_template("admin_forum.html", posts=posts, status_filter=status_filter,
                           pending_count=pending_count, approved_count=approved_count, auto_approve=auto_approve)

@app.route("/admin/forum/toggle_auto_approve", methods=["POST"])
@admin_required
def admin_toggle_forum_auto_approve():
    global SYSTEM_SETTINGS
    SYSTEM_SETTINGS['forum_auto_approve'] = not SYSTEM_SETTINGS.get('forum_auto_approve', True)
    save_system_settings(SYSTEM_SETTINGS)
    status_str = "Aktif (Langsung Terbit)" if SYSTEM_SETTINGS['forum_auto_approve'] else "Nonaktif (Perlu Moderasi Admin)"
    flash(f"Pengaturan Auto-Approve Forum diubah menjadi: {status_str}", "success")
    return redirect(url_for('admin_forum'))

@app.route("/admin/forum/post/<int:post_id>/<action>", methods=["POST"])
@admin_required
def admin_moderate_post(post_id, action):
    post = db.get_or_404(ForumPost, post_id)
    if action == 'approve':
        post.status = 'approved'
        flash("Postingan disetujui dan kini tampil di forum.", "success")
    elif action == 'reject':
        post.status = 'rejected'
        flash("Postingan ditolak.", "warning")
    elif action == 'pin':
        post.is_pinned = not post.is_pinned
        flash(f"Postingan {'disematkan (pinned)' if post.is_pinned else 'batal disematkan'}.", "info")
    elif action == 'delete':
        db.session.delete(post)
        db.session.commit()
        flash("Postingan berhasil dihapus.", "danger")
        return redirect(url_for('admin_forum'))
    else:
        abort(400)
    db.session.commit()
    return redirect(url_for('admin_forum'))

@app.route("/admin/forum/post/official", methods=["POST"])
@admin_required
def admin_create_official_post():
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    amount = clean_decimal_input(request.form.get('amount', '0'))
    bank_name = request.form.get('bank_name', 'Maybank').strip()
    is_pinned = bool(request.form.get('is_pinned'))

    admin_user = User.query.filter_by(role='admin').first()
    author_id = session.get('admin_id') or (admin_user.id if admin_user else 1)

    image_url = ''
    if 'proof_image' in request.files:
        file = request.files['proof_image']
        if file and validate_image(file):
            ext = file.filename.rsplit('.', 1)[1].lower()
            filename = secure_filename(f"official_{int(utc_now().timestamp())}_{os.urandom(4).hex()}.{ext}")
            filepath = os.path.join(app.config['FORUM_UPLOAD_FOLDER'], filename)
            file.save(filepath)
            image_url = url_for('static', filename=f'uploads/forum/{filename}')

    post = ForumPost(user_id=author_id, title=title, content=content, amount=amount,
                     bank_name=bank_name, image_url=image_url, status='approved',
                     is_pinned=is_pinned, likes_count=5)
    db.session.add(post)
    try:
        db.session.commit()
        flash("Bukti penarikan resmi berhasil diterbitkan ke forum!", "success")
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to create official forum post: {e}", exc_info=True)
        flash("Gagal membuat postingan resmi.", "danger")

    return redirect(url_for('admin_forum'))

@app.route("/admin/forum/comment/<int:comment_id>/delete", methods=["POST"])
@admin_required
def admin_delete_comment(comment_id):
    comment = db.get_or_404(ForumComment, comment_id)
    db.session.delete(comment)
    db.session.commit()
    flash("Komentar berhasil dihapus.", "info")
    return redirect(request.referrer or url_for('admin_forum'))

# ------------------------------------------------------------
# Health Check & Static
# ------------------------------------------------------------
@app.route('/favicon.ico')
def favicon():
    svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#3b82f6"/><stop offset="100%" stop-color="#1d4ed8"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="url(#g)"/><path d="M16 42 L26 30 L34 36 L48 18" fill="none" stroke="#ffffff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><polyline points="40,18 48,18 48,26" fill="none" stroke="#ffffff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>"""
    resp = make_response(svg)
    resp.headers['Content-Type'] = 'image/svg+xml'
    resp.headers['Cache-Control'] = 'public, max-age=86400'
    return resp

@app.route('/assets/<path:filename>')
def assets_fallback(filename):
    return ('', 204)

@app.route('/health')
def health():
    return jsonify({"status": "healthy", "timestamp": utc_now().isoformat()})

# ------------------------------------------------------------
# Security Headers
# ------------------------------------------------------------
@app.after_request
def apply_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "frame-ancestors 'self' https://*.globallmarket.pro https://www.globallmarket.pro"
    return response

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------
if __name__ == "__main__":
    def signal_handler(sig, frame):
        logger.info(f"Received signal {sig}, shutting down...")
        sys.exit(0)
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    logger.info("Starting Global Market server (MYR only)...")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5009)), debug=False)