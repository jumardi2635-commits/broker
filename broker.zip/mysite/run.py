# run.py
import sys
import os

# Set UTF-8 encoding environment
os.environ["PYTHONIOENCODING"] = "utf-8"
os.chdir(os.path.dirname(os.path.abspath(__file__)))

print("Starting Trading Platform Application...")
import app
if __name__ == "__main__":
    app.app.run(host="0.0.0.0", port=5009, debug=False)