#!/usr/bin/env python3
"""Migrasi lengkap untuk semua kolom yang diperlukan."""

import sqlite3
import os

# Database utama aplikasi berada di instance/globalmarket.db
_CANDIDATES = [
    os.path.join(os.path.dirname(__file__), 'instance', 'globalmarket.db'),
    os.path.join(os.path.dirname(__file__), 'globalmarket.db'),
]
DB_PATH = next((c for c in _CANDIDATES if os.path.exists(c)), _CANDIDATES[0])

def migrate_all():
    if not os.path.exists(DB_PATH):
        print("❌ Database tidak ditemukan.")
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    def column_exists(table, column):
        cursor.execute(f"PRAGMA table_info({table})")
        return any(col[1] == column for col in cursor.fetchall())

    # Kolom yang perlu ditambahkan ke tabel user
    user_columns = [
        ('preferred_currency', 'VARCHAR(3)', "'USD'"),
        ('profile_picture', 'VARCHAR(255)', 'NULL'),
        ('phone', 'VARCHAR(20)', 'NULL'),
    ]

    for col_name, col_type, default in user_columns:
        if not column_exists('user', col_name):
            try:
                # Untuk default NULL, gunakan DEFAULT NULL tanpa tanda kutip
                if default == 'NULL':
                    cursor.execute(f"ALTER TABLE user ADD COLUMN {col_name} {col_type} DEFAULT NULL")
                else:
                    cursor.execute(f"ALTER TABLE user ADD COLUMN {col_name} {col_type} DEFAULT {default}")
                print(f"✅ Kolom '{col_name}' ditambahkan ke user.")
            except Exception as e:
                print(f"⚠️ Gagal menambahkan {col_name} ke user: {e}")
        else:
            print(f"ℹ️ Kolom '{col_name}' sudah ada di user.")

    # Kolom untuk tabel transactions
    tx_columns = [
        ('admin_notes', 'TEXT', "''"),
        ('updated_at', 'DATETIME', 'CURRENT_TIMESTAMP'),
        ('fee', 'NUMERIC(10,2)', '0.00'),  # Tambahan untuk withdrawal fee
    ]

    for col_name, col_type, default in tx_columns:
        if not column_exists('transactions', col_name):
            try:
                cursor.execute(f"ALTER TABLE transactions ADD COLUMN {col_name} {col_type} DEFAULT {default}")
                print(f"✅ Kolom '{col_name}' ditambahkan ke transactions.")
            except Exception as e:
                print(f"⚠️ Gagal menambahkan {col_name} ke transactions: {e}")
        else:
            print(f"ℹ️ Kolom '{col_name}' sudah ada di transactions.")

    if not column_exists('kyc_verifications', 'bank_account_status'):
        try:
            cursor.execute("ALTER TABLE kyc_verifications ADD COLUMN bank_account_status VARCHAR(20) NOT NULL DEFAULT 'not_submitted'")
            print("✅ Kolom 'bank_account_status' ditambahkan ke kyc_verifications.")
        except Exception as e:
            print(f"⚠️ Gagal menambahkan bank_account_status: {e}")

    # Buat tabel currency_rates jika belum ada
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS currency_rates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            currency VARCHAR(3) UNIQUE NOT NULL,
            rate_to_usd NUMERIC(12, 6) NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("✅ Tabel 'currency_rates' dipastikan ada.")

    # Ledger trade terpisah dan verifikasi KYC (idempoten untuk database lama).
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS trade_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, source VARCHAR(20) NOT NULL DEFAULT 'admin',
            symbol VARCHAR(32) NOT NULL DEFAULT 'UNKNOWN', direction VARCHAR(8) NOT NULL DEFAULT 'buy',
            opened_at DATETIME, closed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, volume NUMERIC(14,4) NOT NULL DEFAULT 0,
            entry_price NUMERIC(18,8), exit_price NUMERIC(18,8), pnl NUMERIC(12,2) NOT NULL DEFAULT 0,
            commission NUMERIC(12,2) NOT NULL DEFAULT 0, swap NUMERIC(12,2) NOT NULL DEFAULT 0,
            fee NUMERIC(12,2) NOT NULL DEFAULT 0, notes VARCHAR(500) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS trade_audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, trade_id INTEGER, user_id INTEGER NOT NULL, admin_id INTEGER,
            action VARCHAR(20) NOT NULL, before_data TEXT NOT NULL DEFAULT '{}', after_data TEXT NOT NULL DEFAULT '{}',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS kyc_verifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL UNIQUE, document_path VARCHAR(512),
            status VARCHAR(20) NOT NULL DEFAULT 'not_submitted', bank_account_status VARCHAR(20) NOT NULL DEFAULT 'not_submitted', rejection_note VARCHAR(500) NOT NULL DEFAULT '',
            submitted_at DATETIME, reviewed_at DATETIME, reviewer_id INTEGER
        )
    """)
    cursor.execute("""
        INSERT INTO trade_history (user_id, source, symbol, direction, closed_at, pnl, notes)
        SELECT t.user_id, 'legacy', 'LEGACY', 'buy', COALESCE(t.created_at, CURRENT_TIMESTAMP), t.amount, COALESCE(t.description, '')
        FROM transactions t WHERE t.type = 'trade' AND NOT EXISTS (
            SELECT 1 FROM trade_history h WHERE h.source = 'legacy' AND h.user_id = t.user_id
              AND h.closed_at = t.created_at AND h.pnl = t.amount
        )
    """)

    # Isi kurs jika kosong
    cursor.execute("SELECT COUNT(*) FROM currency_rates")
    if cursor.fetchone()[0] == 0:
        rates = [
            ('USD', 1.0), ('MYR', 0.21), ('SGD', 0.74), ('BND', 0.74),
            ('IDR', 0.000064), ('EUR', 1.09), ('GBP', 1.27), ('JPY', 0.0067)
        ]
        cursor.executemany("INSERT INTO currency_rates (currency, rate_to_usd) VALUES (?, ?)", rates)
        print("✅ Kurs mata uang default ditambahkan.")

    conn.commit()
    conn.close()
    print("\n🎉 Semua migrasi selesai!")

if __name__ == "__main__":
    migrate_all()
