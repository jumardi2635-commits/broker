# config.py — Konfigurasi terpusat untuk Global Market
# Catatan: app.py saat ini self-contained dan membaca environment secara
# langsung. Modul ini disediakan sebagai referensi konfigurasi yang valid
# dan konsisten (sebelumnya rusak karena `from config import config`
# mengimpor dirinya sendiri).
import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Konfigurasi dasar yang dipakai semua environment."""

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev_secret_key_change_in_production")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///globalmarket.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    PERMANENT_SESSION_LIFETIME = timedelta(hours=1)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("SECURE_COOKIE", "False").lower() == "true"

    MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2 MB

    RATELIMIT_DEFAULT = "2000 per day;300 per hour"

    # Batasan trading
    TRADING_ENABLED = True
    MIN_TRADE_AMOUNT = 1.0
    MAX_TRADE_AMOUNT = 10000.0
    MAX_LEVERAGE = 10

    GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    SESSION_COOKIE_SECURE = True

    @staticmethod
    def init_app(app):
        # Hook untuk hardening produksi tambahan bila diperlukan.
        pass


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": DevelopmentConfig,
}
