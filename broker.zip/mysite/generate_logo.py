#!/usr/bin/env python3
"""
Logo Generator for ASNB
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_favicon():
    """Create favicon.ico"""
    sizes = [(16, 16), (32, 32), (48, 48)]
    images = []

    for size in sizes:
        img = Image.new('RGBA', size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Draw logo
        if size == (16, 16):
            # Simple version for small size - tanpa radius
            draw.rectangle([2, 2, 14, 14], fill=(34, 211, 238))
            # Tambah garis untuk efek rounded corners
            for i in range(3):
                draw.point([2+i, 2], fill=(0, 0, 0, 0))
                draw.point([13-i, 2], fill=(0, 0, 0, 0))
                draw.point([2, 2+i], fill=(0, 0, 0, 0))
                draw.point([2, 13-i], fill=(0, 0, 0, 0))
                draw.point([13, 2+i], fill=(0, 0, 0, 0))
                draw.point([13, 13-i], fill=(0, 0, 0, 0))
                draw.point([2+i, 13], fill=(0, 0, 0, 0))
                draw.point([13-i, 13], fill=(0, 0, 0, 0))

            draw.line([4, 8, 8, 4, 12, 8, 10, 10, 6, 10, 4, 8], fill=(255, 255, 255), width=1)
        elif size == (32, 32):
            # Tanpa radius parameter
            draw.rectangle([4, 4, 28, 28], fill=(34, 211, 238))
            # Tambah efek rounded corners manual
            for i in range(6):
                for j in range(6):
                    if i*i + j*j > 36:  # radius 6
                        draw.point([4+i, 4+j], fill=(0, 0, 0, 0))
                        draw.point([27-i, 4+j], fill=(0, 0, 0, 0))
                        draw.point([4+i, 27-j], fill=(0, 0, 0, 0))
                        draw.point([27-i, 27-j], fill=(0, 0, 0, 0))

            # Chart icon
            points = [(8, 20), (12, 12), (16, 16), (20, 8), (24, 12)]
            draw.line(points, fill=(255, 255, 255), width=2)
        else:  # 48x48
            # Tanpa radius parameter
            draw.rectangle([6, 6, 42, 42], fill=(34, 211, 238))
            # Tambah efek rounded corners manual
            for i in range(8):
                for j in range(8):
                    if i*i + j*j > 64:  # radius 8
                        draw.point([6+i, 6+j], fill=(0, 0, 0, 0))
                        draw.point([41-i, 6+j], fill=(0, 0, 0, 0))
                        draw.point([6+i, 41-j], fill=(0, 0, 0, 0))
                        draw.point([41-i, 41-j], fill=(0, 0, 0, 0))

            # Detailed chart
            points = [(12, 30), (18, 18), (24, 24), (30, 12), (36, 20)]
            draw.line(points, fill=(255, 255, 255), width=3)
            # Fill area under chart (membuat polygon)
            draw.polygon([(12, 30), (18, 18), (24, 24), (30, 12), (36, 20), (36, 30)],
                        fill=(255, 255, 255, 100))

        images.append(img)

    # Save as ICO - perbaiki cara menyimpan multiple sizes
    try:
        images[0].save('static/favicon.ico',
                      format='ICO',
                      sizes=[(16, 16), (32, 32), (48, 48)],
                      append_images=images[1:])
        print("✅ Favicon created: static/favicon.ico")
    except:
        # Fallback: save single size
        images[0].resize((32, 32)).save('static/favicon.ico', format='ICO')
        print("⚠️  Simple favicon created (single size)")

def create_logo_png():
    """Create PNG logo"""
    # Main logo 200x60
    img = Image.new('RGBA', (200, 60), (17, 24, 39, 255))
    draw = ImageDraw.Draw(img)

    # Gradient background for icon (tanpa radius)
    for i in range(40):
        color = (
            int(34 + (6-34)*(i/40)),  # R
            int(211 + (180-211)*(i/40)),  # G
            int(238 + (212-238)*(i/40))   # B
        )
        draw.rectangle([10, 10+i, 50, 10+i+1], fill=color)

    # Tambah efek rounded corners manual untuk icon
    for i in range(8):
        for j in range(8):
            if i*i + j*j > 64:  # radius 8
                draw.point([10+i, 10+j], fill=(17, 24, 39, 255))
                draw.point([49-i, 10+j], fill=(17, 24, 39, 255))
                draw.point([10+i, 49-j], fill=(17, 24, 39, 255))
                draw.point([49-i, 49-j], fill=(17, 24, 39, 255))

    # Add border to icon
    draw.rectangle([10, 10, 50, 50], fill=None, outline=(255, 255, 255, 100), width=1)

    # Chart lines
    points = [(20, 35), (25, 25), (30, 30), (35, 20), (40, 28)]
    draw.line(points, fill=(255, 255, 255), width=2)

    # Fill under chart
    draw.polygon([(20, 35), (25, 25), (30, 30), (35, 20), (40, 28), (40, 35)],
                 fill=(255, 255, 255, 50))

    # Add text
    try:
        # Coba beberapa font umum
        fonts_to_try = [
            "arialbd.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf",
            "LiberationSans-Bold.ttf", "FreeSansBold.ttf"
        ]
        font = None
        for font_name in fonts_to_try:
            try:
                font = ImageFont.truetype(font_name, 28)
                break
            except:
                continue
        if font is None:
            font = ImageFont.load_default()
    except:
        font = ImageFont.load_default()

    # "ASNB" in light blue
    draw.text((65, 15), "TRADE", fill=(34, 211, 238), font=font)
    # "PRO" in darker blue
    draw.text((155, 15), "PRO", fill=(6, 180, 212), font=font)

    # Save
    img.save('static/img/logo.png', 'PNG')
    print("✅ Logo created: static/img/logo.png")

    # Create square version for admin (100x100)
    img_square = Image.new('RGBA', (100, 100), (17, 24, 39, 255))
    draw_square = ImageDraw.Draw(img_square)

    # Circle background (bukan ellipse dengan radius)
    # Gambar lingkaran dengan polygon approximation
    center_x, center_y = 50, 50
    radius = 40
    # Buat polygon untuk lingkaran
    circle_points = []
    for i in range(360):
        angle = i * 3.14159 / 180
        x = center_x + radius * (3.14159/180) * i / 360  # Approximation
        y = center_y + radius * (3.14159/180) * i / 360  # Approximation
        circle_points.append((x, y))
    if circle_points:
        draw_square.polygon(circle_points, fill=(34, 211, 238))

    # Chart in center
    center_points = [(30, 50), (40, 30), (50, 40), (60, 20), (70, 35)]
    draw_square.line(center_points, fill=(255, 255, 255), width=3)

    img_square.save('static/img/logo-square.png', 'PNG')
    print("✅ Square logo created: static/img/logo-square.png")

def create_logo_svg():
    """Create SVG logo (more scalable)"""
    svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
<svg width="200" height="60" viewBox="0 0 200 60" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#22d3ee"/>
      <stop offset="100%" stop-color="#06b6d4"/>
    </linearGradient>
    <linearGradient id="textGradient" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#22d3ee"/>
      <stop offset="100%" stop-color="#06b6d4"/>
    </linearGradient>
  </defs>

  <!-- Icon Container -->
  <rect x="10" y="10" width="40" height="40" rx="8" fill="url(#gradient)"/>

  <!-- Chart Lines -->
  <path d="M20,35 L25,25 L30,30 L35,20 L40,28"
        stroke="#FFFFFF"
        stroke-width="2"
        fill="none"
        stroke-linecap="round"
        stroke-linejoin="round"/>

  <!-- Chart Fill -->
  <path d="M20,35 L25,25 L30,30 L35,20 L40,28 L40,35 L20,35"
        fill="rgba(255,255,255,0.1)"/>

  <!-- Text -->
  <text x="65" y="38"
        font-family="Arial, sans-serif"
        font-size="28"
        font-weight="800"
        fill="url(#textGradient)">
    ASNB
  </text>

  <!-- Optional: Small indicator dots -->
  <circle cx="25" cy="25" r="2" fill="#22c55e"/>
  <circle cx="30" cy="30" r="2" fill="#fbbf24"/>
  <circle cx="35" cy="20" r="2" fill="#ef4444"/>
</svg>'''

    with open('static/img/logo.svg', 'w') as f:
        f.write(svg_content)
    print("✅ SVG logo created: static/img/logo.svg")

def create_simple_logos():
    """Create simple logos without complex graphics"""
    # Create simple text-based logo
    img = Image.new('RGBA', (200, 60), (17, 24, 39, 255))
    draw = ImageDraw.Draw(img)

    try:
        # Try to load a font
        fonts_to_try = ["arial.ttf", "Arial.ttf", "DejaVuSans.ttf"]
        font = None
        for font_name in fonts_to_try:
            try:
                font = ImageFont.truetype(font_name, 32)
                break
            except:
                continue
        if font is None:
            font = ImageFont.load_default()
    except:
        font = ImageFont.load_default()

    # Draw "ASNB" with gradient effect
    for i, char in enumerate("ASNB"):
        # Calculate color position in gradient
        pos = i / (len("TRADE") - 1)
        r = int(34 + (6 - 34) * pos)
        g = int(211 + (180 - 211) * pos)
        b = int(238 + (212 - 238) * pos)

        # Position text
        x = 20 + i * 20
        draw.text((x, 15), char, fill=(r, g, b), font=font)

    # Add a simple chart line below text
    points = [(20, 50), (40, 45), (60, 48), (80, 42), (100, 46),
              (120, 40), (140, 44), (160, 38), (180, 42)]
    draw.line(points, fill=(34, 211, 238), width=2)

    img.save('static/img/logo-simple.png', 'PNG')
    print("✅ Simple logo created: static/img/logo-simple.png")

    # Create a very simple favicon (32x32)
    favicon = Image.new('RGBA', (32, 32), (34, 211, 238))
    draw_fav = ImageDraw.Draw(favicon)

    # Draw a simple upward trend line
    draw_fav.line([(8, 24), (16, 16), (24, 20)], fill=(255, 255, 255), width=3)

    favicon.save('static/favicon-simple.ico', format='ICO')
    print("✅ Simple favicon created: static/favicon-simple.ico")

def create_app_icon():
    """Create app icon for mobile/pwa - simplified version"""
    sizes = [72, 96, 128, 144, 152, 192, 384, 512]

    for size in sizes:
        img = Image.new('RGBA', (size, size), (17, 24, 39, 255))
        draw = ImageDraw.Draw(img)

        # Simple square with gradient (no rounded corners)
        margin = int(size * 0.1)
        square_size = size - 2*margin

        # Draw gradient
        for i in range(square_size):
            color_pos = i / square_size
            r = int(34 + (6 - 34) * color_pos)
            g = int(211 + (180 - 211) * color_pos)
            b = int(238 + (212 - 238) * color_pos)
            draw.rectangle([margin, margin + i, margin + square_size, margin + i + 1],
                          fill=(r, g, b))

        # Simple chart line
        chart_margin = int(size * 0.2)
        chart_width = size - 2*chart_margin
        points = []
        for i in range(5):
            x = chart_margin + (i * chart_width // 4)
            # Alternate up and down
            if i % 2 == 0:
                y = size // 2 + chart_width // 8
            else:
                y = size // 2 - chart_width // 8
            points.append((x, y))

        if len(points) > 1:
            draw.line(points, fill=(255, 255, 255), width=max(3, size//48))

        # Save
        img.save(f'static/img/icon-{size}x{size}.png', 'PNG')

    print("✅ App icons created in static/img/")

def main():
    """Create all logo files"""
    # Create directories
    os.makedirs('static/img', exist_ok=True)

    print("🎨 Generating TraderPro logos...")

    try:
        # Create simple logos first (most reliable)
        create_simple_logos()

        # Then try more complex logos
        create_logo_png()
        create_logo_svg()
        create_app_icon()

        # Favicon might fail, so try it last
        try:
            create_favicon()
        except Exception as e:
            print(f"⚠️  Could not create complex favicon: {e}")
            print("   Using simple favicon instead")

    except Exception as e:
        print(f"❌ Error creating logos: {e}")
        print("Trying fallback...")

        # Fallback: create absolute minimum
        img = Image.new('RGB', (200, 60), (17, 24, 39))
        img.save('static/img/logo-fallback.png', 'PNG')

        # Simple favicon
        img = Image.new('RGB', (32, 32), (34, 211, 238))
        img.save('static/favicon.ico', format='ICO')

    print("\n✅ Logo generation completed!")
    print("📁 Files created in static/ folder:")

    # List created files
    for root, dirs, files in os.walk('static'):
        for file in files:
            if file.endswith(('.png', '.svg', '.ico')):
                print(f"  - {os.path.join(root, file)}")

if __name__ == "__main__":
    main()