#!/usr/bin/env python3
# ============================================================
# PDF Generator — Broker-Grade Disbursement Voucher
# Fixed version: no linearGradient/clipPath (max compatibility)
# Matches the HTML voucher design
# ============================================================
import hashlib
import traceback
from io import BytesIO
from datetime import datetime, timezone

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib import colors
from reportlab.lib.units import mm

try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False


# ============================================================
# COLOR PALETTE
# ============================================================
NAVY        = colors.HexColor('#0f172a')
NAVY_SOFT   = colors.HexColor('#1e293b')
BLUE_DEEP   = colors.HexColor('#1e3a8a')
BLUE        = colors.HexColor('#2563eb')
BLUE_LIGHT  = colors.HexColor('#3b82f6')
BLUE_SKY    = colors.HexColor('#60a5fa')
BLUE_PALE   = colors.HexColor('#dbeafe')
BLUE_BG     = colors.HexColor('#eff6ff')
BLUE_BORDER = colors.HexColor('#bfdbfe')

NAVY_TEXT   = colors.HexColor('#0a1628')
TEXT_DARK   = colors.HexColor('#0f172a')
TEXT_MED    = colors.HexColor('#334155')
TEXT_MUTED  = colors.HexColor('#64748b')
TEXT_DIM    = colors.HexColor('#94a3b8')

PAPER       = colors.white
CREAM       = colors.HexColor('#f8fafc')
SLATE_50    = colors.HexColor('#f8fafc')
SLATE_100   = colors.HexColor('#f1f5f9')
SLATE_200   = colors.HexColor('#e2e8f0')
SLATE_300   = colors.HexColor('#cbd5e1')

GREEN       = colors.HexColor('#34d399')
GREEN_DARK  = colors.HexColor('#059669')
GREEN_BG    = colors.HexColor('#ecfdf5')
GREEN_BORD  = colors.HexColor('#a7f3d0')

AMBER       = colors.HexColor('#fbbf24')
AMBER_DARK  = colors.HexColor('#b45309')
AMBER_BG    = colors.HexColor('#fffbeb')
AMBER_BORD  = colors.HexColor('#fde68a')

RED         = colors.HexColor('#f87171')
RED_DARK    = colors.HexColor('#be123c')
RED_BG      = colors.HexColor('#fff1f2')
RED_BORD    = colors.HexColor('#fecdd3')

WHITE       = colors.white


# ============================================================
# HELPERS
# ============================================================
def _fmt(dt, fmt='%d %b %Y, %H:%M'):
    if not dt:
        return '—'
    try:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.strftime(fmt)
    except Exception:
        return '—'


def _truncate(text, max_chars):
    if text is None:
        return '—'
    s = str(text)
    if not s:
        return '—'
    return s if len(s) <= max_chars else s[:max_chars - 1] + '…'


def _make_qr_image(data):
    if not HAS_QRCODE:
        return None
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=1,
        )
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#0a1628", back_color="white")
        buf = BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        return buf
    except Exception:
        return None


def _draw_wrapped(c, text, x, y, max_width, font='Helvetica', size=8, line_h=10, color=TEXT_MED):
    """Draw wrapped text, return the y after the last line."""
    c.setFont(font, size)
    c.setFillColor(color)
    words = str(text or '').split()
    if not words:
        return y
    line = ''
    lines = []
    for w in words:
        test = (line + ' ' + w).strip()
        if c.stringWidth(test, font, size) <= max_width:
            line = test
        else:
            if line:
                lines.append(line)
            line = w
    if line:
        lines.append(line)
    yy = y
    for l in lines:
        c.drawString(x, yy, l)
        yy -= line_h
    return yy


def _dashed_round_rect(c, x, y, w, h, radius, stroke_color, line_width=0.5, dash=(2, 2)):
    """Draw a dashed rounded rectangle safely."""
    try:
        c.saveState()
        c.setStrokeColor(stroke_color)
        c.setLineWidth(line_width)
        c.setDash(list(dash), 0)
        c.roundRect(x, y, w, h, radius, fill=0, stroke=1)
        c.restoreState()
    except Exception:
        pass


def _solid_alpha(c, rgb_tuple, alpha):
    """Set fill color with alpha (safe)."""
    try:
        r, g, b = rgb_tuple
        c.setFillColor(colors.Color(r, g, b, alpha=alpha))
    except Exception:
        c.setFillColor(colors.Color(r, g, b))


def _hex_to_rgb01(hex_color):
    """Return (r, g, b) as floats in [0, 1] from a HexColor."""
    try:
        return (hex_color.red, hex_color.green, hex_color.blue)
    except Exception:
        return (0.5, 0.5, 0.5)


# ============================================================
# MAIN — PDF GENERATOR
# ============================================================
def generate_professional_voucher(withdrawal, user, kyc, site, verify_url='', logo_path=None):
    """
    Generate a professional broker-grade PDF voucher.
    Single page, navy/blue professional broker style.
    """
    try:
        return _generate_voucher_impl(withdrawal, user, kyc, site, verify_url, logo_path)
    except Exception as e:
        # Print full traceback to help diagnose
        print("=" * 70)
        print("PDF GENERATION ERROR:")
        print(f"  Withdrawal ID: {getattr(withdrawal, 'id', '?')}")
        print(f"  Exception: {type(e).__name__}: {e}")
        traceback.print_exc()
        print("=" * 70)
        # Return a minimal fallback PDF so the user gets *something*
        return _fallback_pdf(withdrawal, site, str(e))


def _fallback_pdf(withdrawal, site, error_msg):
    """Minimal PDF fallback if main generation fails."""
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    W, H = A4

    c.setFillColor(NAVY)
    c.rect(0, H - 30 * mm, W, 30 * mm, fill=1, stroke=0)
    c.setFillColor(WHITE)
    c.setFont('Helvetica-Bold', 16)
    c.drawString(20 * mm, H - 20 * mm, site.get('site_name', 'Global Market'))

    c.setFillColor(TEXT_DARK)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(20 * mm, H - 55 * mm, "Disbursement Voucher")

    c.setFont('Helvetica', 11)
    c.drawString(20 * mm, H - 70 * mm, f"Reference: WD-{withdrawal.id:06d}")

    c.setFont('Helvetica-Bold', 12)
    c.drawString(20 * mm, H - 90 * mm, f"Amount: RM {float(withdrawal.amount):,.2f}")

    c.setFont('Helvetica', 9)
    c.setFillColor(TEXT_MUTED)
    c.drawString(20 * mm, H - 110 * mm, "This is a system-generated placeholder.")
    c.drawString(20 * mm, H - 118 * mm, f"Reason: {error_msg[:120]}")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()


def _generate_voucher_impl(withdrawal, user, kyc, site, verify_url='', logo_path=None):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    c.setTitle(f"Disbursement Voucher - WD-{withdrawal.id:06d}")
    c.setAuthor(site.get('site_name', 'Global Market'))
    c.setSubject("Official Withdrawal Voucher")
    c.setCreator("Global Market Trading Platform")

    W, H = A4
    M = 10 * mm
    card_w = W - 2 * M

    # ============================================================
    # METADATA
    # ============================================================
    doc_ref = f"WD-{withdrawal.id:06d}"
    txn_id = f"TXN-WD-{withdrawal.id:08d}"
    doc_id = f"DOC-{withdrawal.id:012d}"

    try:
        raw_hash = f"{withdrawal.id}|{withdrawal.amount}|{withdrawal.created_at}|{withdrawal.bank_account}"
        doc_hash = hashlib.sha256(raw_hash.encode('utf-8')).hexdigest().upper()
    except Exception:
        doc_hash = '0' * 64

    # Status
    status_raw = (withdrawal.status or 'pending').lower()
    if status_raw == 'approved':
        s_fg, s_bg, s_bord = GREEN_DARK, GREEN_BG, GREEN_BORD
    elif status_raw == 'pending':
        s_fg, s_bg, s_bord = AMBER_DARK, AMBER_BG, AMBER_BORD
    else:
        s_fg, s_bg, s_bord = RED_DARK, RED_BG, RED_BORD

    # Amount
    try:
        amount_val = float(withdrawal.amount or 0)
    except (TypeError, ValueError):
        amount_val = 0.0

    # Dates
    now = datetime.now(timezone.utc)
    created_str = _fmt(getattr(withdrawal, 'created_at', None), '%d %b %Y, %H:%M:%S')
    submitted_str = _fmt(getattr(withdrawal, 'created_at', None), '%d %B %Y, %H:%M:%S')
    issued_str = now.strftime('%d %b %Y %H:%M UTC')

    # KYC
    kyc_status = 'not_submitted'
    bank_status = 'not_submitted'
    if kyc is not None:
        kyc_status = getattr(kyc, 'status', 'not_submitted') or 'not_submitted'
        bank_status = getattr(kyc, 'bank_account_status', 'not_submitted') or 'not_submitted'

    # ============================================================
    # LAYOUT
    # ============================================================
    ACCENT_H = 1.8 * mm
    HEADER_H = 42 * mm
    FOOTER_H = 12 * mm

    card_top = H - M
    card_bottom = M
    header_top = card_top - ACCENT_H
    header_bottom = header_top - HEADER_H
    footer_top = card_bottom + FOOTER_H

    # ============================================================
    # 1. OUTER CARD BORDER
    # ============================================================
    c.setStrokeColor(SLATE_200)
    c.setLineWidth(0.5)
    c.roundRect(M, card_bottom, card_w, card_top - card_bottom, 3, fill=0, stroke=1)

    # ============================================================
    # 2. HEADER — solid navy
    # ============================================================
    c.setFillColor(NAVY)
    c.rect(M, header_bottom, card_w, HEADER_H, fill=1, stroke=0)

    # ============================================================
    # 3. TOP ACCENT BAR — 3-color segments (visual "gradient")
    # ============================================================
    seg_w = card_w / 3
    c.setFillColor(BLUE_DEEP)
    c.rect(M, card_top - ACCENT_H, seg_w, ACCENT_H, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.rect(M + seg_w, card_top - ACCENT_H, seg_w, ACCENT_H, fill=1, stroke=0)
    c.setFillColor(BLUE_LIGHT)
    c.rect(M + 2 * seg_w, card_top - ACCENT_H, seg_w, ACCENT_H, fill=1, stroke=0)

    # ============================================================
    # 4. BRAND SEAL
    # ============================================================
    seal_size = 14 * mm
    seal_x = M + 7 * mm
    seal_y = header_top - seal_size - 7 * mm

    # Outer glow ring (solid color, low alpha)
    _solid_alpha(c, _hex_to_rgb01(BLUE), 0.15)
    c.roundRect(seal_x - 1.5 * mm, seal_y - 1.5 * mm,
                seal_size + 3 * mm, seal_size + 3 * mm, 3, fill=1, stroke=0)

    # Seal gradient effect via two stacked rects
    c.setFillColor(BLUE)
    c.roundRect(seal_x, seal_y, seal_size, seal_size, 2.5, fill=1, stroke=0)

    # Logo or "GM" fallback
    logo_drawn = False
    if logo_path:
        try:
            from pathlib import Path as _P
            if _P(logo_path).exists():
                c.setFillColor(WHITE)
                c.roundRect(seal_x + 1, seal_y + 1, seal_size - 2, seal_size - 2, 2, fill=1, stroke=0)
                img = ImageReader(logo_path)
                c.drawImage(img, seal_x + 2, seal_y + 2,
                            seal_size - 4, seal_size - 4,
                            preserveAspectRatio=True, mask='auto')
                logo_drawn = True
        except Exception:
            logo_drawn = False

    if not logo_drawn:
        c.setFillColor(WHITE)
        c.setFont('Helvetica-Bold', 17)
        c.drawCentredString(seal_x + seal_size / 2, seal_y + seal_size / 2 - 5, "GM")

    # ============================================================
    # 5. BRAND TEXT
    # ============================================================
    bx = seal_x + seal_size + 5 * mm
    by_top = header_top - 9 * mm

    c.setFillColor(colors.HexColor('#93c5fd'))
    c.setFont('Helvetica-Bold', 6)
    c.drawString(bx, by_top, "GLOBAL MARKET TRADE")

    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Helvetica', 6.5)
    c.drawString(bx, by_top - 20, "Licensed Financial Services Provider")

    # ============================================================
    # 6. RIGHT META (Document Type / REF)
    # ============================================================
    rx = M + card_w - 7 * mm

    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Helvetica-Bold', 5.5)
    c.drawRightString(rx, by_top, "DOCUMENT TYPE")

    c.setFillColor(colors.HexColor('#93c5fd'))
    c.setFont('Times-Bold', 11)
    c.drawRightString(rx, by_top - 10, "Withdrawal")

    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Courier-Bold', 7)
    c.drawRightString(rx, by_top - 18, f"REF: {doc_ref}")

    # ============================================================
    # 7. STATUS PILL ROW
    # ============================================================
    pill_h = 6 * mm
    pill_w = 26 * mm
    pill_x = M + 8 * mm
    pill_y = header_bottom + 7 * mm

    # Soft glow behind pill
    _solid_alpha(c, _hex_to_rgb01(s_fg), 0.08)
    c.circle(pill_x + pill_w / 2, pill_y + pill_h / 2, 9 * mm, fill=1, stroke=0)

    # Pill background
    _solid_alpha(c, _hex_to_rgb01(s_fg), 0.15)
    c.roundRect(pill_x, pill_y, pill_w, pill_h, 2, fill=1, stroke=0)

    # Pill border
    c.setStrokeColor(s_fg)
    c.setLineWidth(0.4)
    c.roundRect(pill_x, pill_y, pill_w, pill_h, 2, fill=0, stroke=1)

    # Status dot
    dot_x = pill_x + 4 * mm
    dot_y = pill_y + pill_h / 2
    c.setFillColor(s_fg)
    c.circle(dot_x, dot_y, 1.1 * mm, fill=1, stroke=0)

    # Status text
    c.setFillColor(s_fg)
    c.setFont('Courier-Bold', 7)
    c.drawString(dot_x + 3 * mm, dot_y - 2.2, status_raw.upper())

    # Timestamp next to pill
    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Courier', 6.5)
    c.drawString(pill_x + pill_w + 4 * mm, dot_y - 2, created_str)

    # ============================================================
    # 8. HEADER DIVIDER
    # ============================================================
    c.setStrokeColor(BLUE_DEEP)
    c.setLineWidth(0.4)
    c.line(M + 7 * mm, header_bottom + 3 * mm,
           M + card_w - 7 * mm, header_bottom + 3 * mm)

    # ============================================================
    # 9. BODY BACKGROUND (solid cream)
    # ============================================================
    body_x = M + 8 * mm
    body_w = card_w - 16 * mm
    body_top = header_bottom - 5 * mm

    c.setFillColor(CREAM)
    c.rect(M, footer_top, card_w, body_top - footer_top, fill=1, stroke=0)

    # ============================================================
    # 10. WATERMARK
    # ============================================================
    try:
        c.saveState()
        _solid_alpha(c, (0.06, 0.09, 0.16), 0.025)
        c.setFont('Times-Bold', 72)
        c.translate(W / 2, H / 2 + 20 * mm)
        c.rotate(-12)
        c.drawCentredString(0, 0, "GLOBAL")
        c.restoreState()
    except Exception:
        pass

    # ============================================================
    # 11. AMOUNT SECTION
    # ============================================================
    y = body_top

    c.setFillColor(TEXT_DIM)
    c.setFont('Helvetica-Bold', 6.5)
    c.drawString(body_x, y - 2 * mm, "SETTLEMENT AMOUNT")

    c.setFillColor(BLUE)
    c.setFont('Helvetica-Bold', 6)
    c.drawRightString(body_x + body_w, y - 2 * mm, "◆ VERIFIED SECURE")

    y -= 5 * mm

    # ---------- Amount box ----------
    ab_h = 22 * mm
    ab_y = y - ab_h

    # Box bg
    c.setFillColor(WHITE)
    c.rect(body_x, ab_y, body_w, ab_h, fill=1, stroke=0)

    # Box border
    c.setStrokeColor(SLATE_200)
    c.setLineWidth(0.5)
    c.rect(body_x, ab_y, body_w, ab_h, fill=0, stroke=1)

    # Top accent bar on box (3 segments)
    top_bar_h = 1 * mm
    seg_w = body_w / 3
    c.setFillColor(BLUE_DEEP)
    c.rect(body_x, ab_y + ab_h - top_bar_h, seg_w, top_bar_h, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.rect(body_x + seg_w, ab_y + ab_h - top_bar_h, seg_w, top_bar_h, fill=1, stroke=0)
    c.setFillColor(BLUE_LIGHT)
    c.rect(body_x + 2 * seg_w, ab_y + ab_h - top_bar_h, seg_w, top_bar_h, fill=1, stroke=0)

    # Amount
    baseline = ab_y + 8 * mm
    c.setFillColor(BLUE)
    c.setFont('Courier-Bold', 11)
    c.drawString(body_x + 6 * mm, baseline, "RM")

    c.setFillColor(NAVY_TEXT)
    c.setFont('Courier-Bold', 22)
    c.drawString(body_x + 6 * mm + 11 * mm, baseline, f"{amount_val:,.2f}")

    # Sub-line
    c.setFillColor(TEXT_DIM)
    c.setFont('Helvetica', 6.5)
    c.drawString(body_x + 6 * mm, ab_y + 3.5 * mm,
                 f"Equivalent to USD {amount_val:,.2f}  ·  Exchange rate applied")

    y = ab_y - 6 * mm

    # ============================================================
    # 12. VERIFICATION STATUS — 2 cards
    # ============================================================
    c.setFillColor(TEXT_DIM)
    c.setFont('Helvetica-Bold', 6.5)
    c.drawString(body_x, y, "VERIFICATION STATUS")

    c.setStrokeColor(SLATE_200)
    c.setLineWidth(0.4)
    c.line(body_x + 38 * mm, y + 2, body_x + body_w, y + 2)

    y -= 5 * mm

    v_gap = 4 * mm
    v_w = (body_w - v_gap) / 2
    v_h = 11 * mm
    v_y = y - v_h

    def _vcolor(st):
        s = (st or '').lower()
        if s == 'approved':
            return GREEN_DARK, GREEN_BG, GREEN_BORD, 'Approved'
        if s == 'pending':
            return AMBER_DARK, AMBER_BG, AMBER_BORD, 'Pending'
        if s == 'rejected':
            return RED_DARK, RED_BG, RED_BORD, 'Rejected'
        return TEXT_MUTED, SLATE_50, SLATE_200, 'Not Submitted'

    cards_data = [
        ("ACCOUNT VERIFICATION", kyc_status),
        ("BANK VERIFICATION", bank_status),
    ]

    for i, (label, st) in enumerate(cards_data):
        cx = body_x + i * (v_w + v_gap)
        cy = v_y

        # Card bg
        c.setFillColor(WHITE)
        c.rect(cx, cy, v_w, v_h, fill=1, stroke=0)

        # Card border
        c.setStrokeColor(SLATE_200)
        c.setLineWidth(0.4)
        c.rect(cx, cy, v_w, v_h, fill=0, stroke=1)

        # Label
        c.setFillColor(TEXT_MUTED)
        c.setFont('Helvetica-Bold', 6)
        c.drawString(cx + 4 * mm, cy + v_h - 4 * mm, label)

        # Status badge
        fg, bg, bord, txt = _vcolor(st)
        badge_txt = txt.upper()
        badge_font = 'Courier-Bold'
        badge_size = 6.5
        tw = c.stringWidth(badge_txt, badge_font, badge_size)
        badge_w = tw + 6 * mm
        badge_h = 5 * mm
        badge_x = cx + v_w - badge_w - 3 * mm
        badge_y = cy + 3 * mm

        # Badge bg
        c.setFillColor(bg)
        c.roundRect(badge_x, badge_y, badge_w, badge_h, 1, fill=1, stroke=0)

        # Badge border
        c.setStrokeColor(bord)
        c.setLineWidth(0.35)
        c.roundRect(badge_x, badge_y, badge_w, badge_h, 1, fill=0, stroke=1)

        # Badge text
        c.setFillColor(fg)
        c.setFont(badge_font, badge_size)
        c.drawCentredString(badge_x + badge_w / 2, badge_y + 1.7 * mm, badge_txt)

    y = v_y - 6 * mm

    # ============================================================
    # 13. TRANSACTION DETAILS — 2-col grid
    # ============================================================
    c.setFillColor(TEXT_DIM)
    c.setFont('Helvetica-Bold', 6.5)
    c.drawString(body_x, y, "TRANSACTION DETAILS")

    c.setStrokeColor(SLATE_200)
    c.setLineWidth(0.4)
    c.line(body_x + 42 * mm, y + 2, body_x + body_w, y + 2)

    y -= 5 * mm

    cell_h = 11 * mm
    col_w = body_w / 2

    details = [
        ("BENEFICIARY NAME", getattr(withdrawal, 'bank_account_name', '') or '—', True),
        ("DESTINATION BANK", getattr(withdrawal, 'bank_name', '') or '—', False),
        ("ACCOUNT NUMBER", getattr(withdrawal, 'bank_account', '') or '—', False),
        ("WITHDRAWAL METHOD", "Bank Wire Transfer", False),
        ("SUBMISSION TIME", submitted_str, False),
        ("TRANSACTION ID", txn_id, False),
    ]

    detail_top = y
    for i, (label, value, is_highlight) in enumerate(details):
        row = i // 2
        col = i % 2
        cx = body_x + col * col_w
        cy = detail_top - (row + 1) * cell_h

        # Cell bg
        c.setFillColor(WHITE)
        c.rect(cx, cy, col_w, cell_h, fill=1, stroke=0)

        # Cell border
        c.setStrokeColor(SLATE_100)
        c.setLineWidth(0.35)
        c.rect(cx, cy, col_w, cell_h, fill=0, stroke=1)

        # Label
        c.setFillColor(TEXT_DIM)
        c.setFont('Helvetica-Bold', 5.5)
        c.drawString(cx + 4 * mm, cy + cell_h - 3.5 * mm, label)

        # Value
        if is_highlight:
            c.setFillColor(NAVY_TEXT)
            c.setFont('Helvetica-Bold', 8)
        elif label in ("ACCOUNT NUMBER", "TRANSACTION ID"):
            c.setFillColor(TEXT_MED)
            c.setFont('Courier-Bold', 7.5)
        else:
            c.setFillColor(NAVY_TEXT)
            c.setFont('Helvetica-Bold', 7.5)

        c.drawString(cx + 4 * mm, cy + 2.5 * mm, _truncate(value, 40))

    y = detail_top - 3 * cell_h - 5 * mm

    # ============================================================
    # 14. QR + HASH SECTION
    # ============================================================
    qr_h = 18 * mm
    qr_y = y - qr_h

    # Dashed border
    _dashed_round_rect(c, body_x, qr_y, body_w, qr_h, 1.5, BLUE_BORDER, 0.5, (2, 2))

    # QR
    qr_size = 14 * mm
    qr_x = body_x + 3 * mm
    qr_iy = qr_y + (qr_h - qr_size) / 2
    qr_img = _make_qr_image(verify_url or f"https://verify.example.com/{doc_ref}")

    if qr_img:
        try:
            c.setFillColor(BLUE_BG)
            c.roundRect(qr_x, qr_iy, qr_size, qr_size, 1, fill=1, stroke=0)
            c.drawImage(ImageReader(qr_img), qr_x + 0.8, qr_iy + 0.8,
                        qr_size - 1.6, qr_size - 1.6, mask='auto')
        except Exception:
            c.setFillColor(BLUE_BG)
            c.roundRect(qr_x, qr_iy, qr_size, qr_size, 1, fill=1, stroke=0)
            c.setFillColor(BLUE)
            c.setFont('Helvetica-Bold', 8)
            c.drawCentredString(qr_x + qr_size / 2, qr_iy + qr_size / 2 - 3, "QR")
    else:
        c.setFillColor(BLUE_BG)
        c.roundRect(qr_x, qr_iy, qr_size, qr_size, 1, fill=1, stroke=0)
        c.setFillColor(BLUE)
        c.setFont('Helvetica-Bold', 8)
        c.drawCentredString(qr_x + qr_size / 2, qr_iy + qr_size / 2 - 3, "QR")

    # Right side text
    tx = qr_x + qr_size + 4 * mm
    ty = qr_y + qr_h - 4.5 * mm

    c.setFillColor(NAVY_TEXT)
    c.setFont('Helvetica-Bold', 7)
    c.drawString(tx, ty, "Document Verification")

    c.setFillColor(TEXT_MUTED)
    c.setFont('Helvetica', 6)
    c.drawString(tx, ty - 4 * mm,
                 "Scan to authenticate this disbursement on the verification portal.")

    c.setFillColor(TEXT_DIM)
    c.setFont('Courier-Bold', 5.5)
    c.drawString(tx, ty - 8 * mm, f"SHA-256: {doc_hash[:40]}…")

    y = qr_y - 5 * mm

    # ============================================================
    # 15. COMPLIANCE NOTICE
    # ============================================================
    comp_h = 16 * mm
    comp_y = y - comp_h

    # Bg
    c.setFillColor(BLUE_BG)
    c.rect(body_x, comp_y, body_w, comp_h, fill=1, stroke=0)

    # Border
    c.setStrokeColor(BLUE_BORDER)
    c.setLineWidth(0.4)
    c.rect(body_x, comp_y, body_w, comp_h, fill=0, stroke=1)

    # Left accent bar
    c.setFillColor(BLUE)
    c.rect(body_x, comp_y, 1 * mm, comp_h, fill=1, stroke=0)

    # Title
    c.setFillColor(colors.HexColor('#1e40af'))
    c.setFont('Helvetica-Bold', 6.5)
    c.drawString(body_x + 4 * mm, comp_y + comp_h - 4 * mm, "REGULATORY COMPLIANCE NOTICE")

    # Body
    _draw_wrapped(
        c,
        "Compliance deposit of RM5,000 may be required for high-value fund release. "
        "This document is a valid proof of disbursement under the Securities Commission Malaysia framework "
        "and shall not be altered or duplicated without written authorization.",
        body_x + 4 * mm, comp_y + comp_h - 8 * mm,
        body_w - 10 * mm,
        font='Helvetica', size=6, line_h=7.5,
        color=colors.HexColor('#1e3a8a')
    )

    y = comp_y - 4 * mm

    # ============================================================
    # 16. AUDITOR REMARKS (optional)
    # ============================================================
    admin_notes = getattr(withdrawal, 'admin_notes', None)
    if admin_notes and str(admin_notes).strip():
        notes_h = 10 * mm
        notes_y = y - notes_h

        c.setFillColor(CREAM)
        c.rect(body_x, notes_y, body_w, notes_h, fill=1, stroke=0)
        c.setStrokeColor(SLATE_200)
        c.setLineWidth(0.35)
        c.rect(body_x, notes_y, body_w, notes_h, fill=0, stroke=1)

        c.setFillColor(TEXT_DIM)
        c.setFont('Helvetica-Bold', 5.5)
        c.drawString(body_x + 4 * mm, notes_y + notes_h - 3.5 * mm, "AUDITOR REMARKS")

        c.setFillColor(TEXT_MED)
        c.setFont('Helvetica', 6.5)
        c.drawString(body_x + 4 * mm, notes_y + 2.5 * mm, _truncate(str(admin_notes), 90))

        y = notes_y - 4 * mm

    # ============================================================
    # 17. SIGNATURE BLOCK
    # ============================================================
    sig_h = 14 * mm
    sig_y = max(y - sig_h, footer_top + 4 * mm)

    # Top divider
    c.setStrokeColor(SLATE_200)
    c.setLineWidth(0.5)
    c.line(body_x, sig_y + sig_h, body_x + body_w, sig_y + sig_h)

    sig_gap = 6 * mm
    sig_col_w = (body_w - 2 * sig_gap) / 3

    sigs = [
        ("PREPARED BY", "System Administrator"),
        ("COMPLIANCE OFFICER", "Risk & Compliance Dept"),
        ("AUTHORIZED BY", "Treasury Manager"),
    ]

    for i, (title, name) in enumerate(sigs):
        cx = body_x + i * (sig_col_w + sig_gap)
        ccx = cx + sig_col_w / 2

        # Signature line
        c.setStrokeColor(TEXT_DIM)
        c.setLineWidth(0.5)
        c.line(cx + 3 * mm, sig_y + sig_h - 3 * mm,
               cx + sig_col_w - 3 * mm, sig_y + sig_h - 3 * mm)

        # Title
        c.setFillColor(TEXT_MUTED)
        c.setFont('Helvetica-Bold', 5.5)
        c.drawCentredString(ccx, sig_y + sig_h - 7 * mm, title)

        # Name
        c.setFillColor(NAVY_TEXT)
        c.setFont('Helvetica-Bold', 7.5)
        c.drawCentredString(ccx, sig_y + sig_h - 10.5 * mm, name)

    # ============================================================
    # 18. FOOTER — solid navy
    # ============================================================
    c.setFillColor(NAVY)
    c.rect(M, card_bottom, card_w, FOOTER_H, fill=1, stroke=0)

    # Top accent on footer
    c.setFillColor(BLUE)
    c.rect(M, card_bottom + FOOTER_H - 0.3 * mm, card_w, 0.3 * mm, fill=1, stroke=0)

    # Left: check + text
    c.setFillColor(GREEN)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(M + 6 * mm, card_bottom + FOOTER_H / 2 - 2, "✓")

    c.setFillColor(colors.HexColor('#e2e8f0'))
    c.setFont('Helvetica-Bold', 7)
    c.drawString(M + 11 * mm, card_bottom + FOOTER_H / 2 - 2,
                 f"Verified & Secured by {site.get('site_name', 'Global Market')}")

    # Center: doc id
    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Courier-Bold', 6.5)
    c.drawCentredString(W / 2, card_bottom + FOOTER_H / 2 - 2, doc_id)

    # Right: CONFIDENTIAL
    c.setFillColor(colors.HexColor('#94a3b8'))
    c.setFont('Helvetica-Bold', 6)
    c.drawRightString(M + card_w - 6 * mm, card_bottom + FOOTER_H / 2 - 2, "CONFIDENTIAL")

    # ============================================================
    # 19. TIMESTAMP below card
    # ============================================================
    c.setFillColor(TEXT_DIM)
    c.setFont('Courier', 6)
    c.drawCentredString(W / 2, card_bottom - 5 * mm,
                        f"Generated {issued_str}  ·  Document ID: {doc_id}")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()